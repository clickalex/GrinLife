/**
 * Golden Orbit style reminder: a cinematic editorial journey through chance, consent, and privacy.
 * Keep the experience asymmetric, nocturnal, and human-scale; never add social-status UI patterns.
 */
import { ExperienceSection } from "@/components/ExperienceSection";
import { Footer } from "@/components/Footer";
import { HeroSection } from "@/components/HeroSection";
import { Navbar } from "@/components/Navbar";
import { RoadmapSection } from "@/components/RoadmapSection";
import { RulesSection } from "@/components/RulesSection";
import { SafetySection } from "@/components/SafetySection";

export default function Home() {
  return (
    <div className="site-frame">
      <Navbar />
      <main>
        <HeroSection />
        <ExperienceSection />
        <RulesSection />
        <SafetySection />
        <RoadmapSection />
      </main>
      <Footer />
    </div>
  );
}
