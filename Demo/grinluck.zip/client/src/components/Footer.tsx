/**
 * Golden Orbit style reminder: the closing stays compact, private, and editorial;
 * finish on the brand mark and the single promise, never a generic marketing footer.
 */
import { ArrowUp } from "lucide-react";

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-rule" />
      <div className="footer-main">
        <a href="#top" className="brand brand--footer" aria-label="Back to the top">
          <img src="/manus-storage/grinluck-orbit-mark_2eb6808c.png" alt="" className="brand-mark" />
          <span>GRIN<span className="brand-accent">LUCK</span></span>
        </a>
        <p>Meet by chance. Talk without judgment.<br />Stay by mutual choice.</p>
        <a href="#top" className="back-top">Back to top <ArrowUp size={15} /></a>
      </div>
      <div className="footer-bottom"><span>© 2026 GrinLuck</span><span>Designed around chance, consent, and privacy.</span></div>
    </footer>
  );
}
