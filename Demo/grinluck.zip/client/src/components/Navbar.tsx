/**
 * Golden Orbit style reminder: calm editorial navigation, obsidian surfaces,
 * Solar Amber only for meaningful choice, and orbit-line details rather than generic pills.
 */
import { Menu, X, ArrowUpRight } from "lucide-react";
import { useEffect, useState } from "react";

const links = [
  { label: "The moment", href: "#moment" },
  { label: "The rules", href: "#rules" },
  { label: "Safety", href: "#safety" },
  { label: "Roadmap", href: "#roadmap" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`site-nav ${scrolled ? "site-nav--scrolled" : ""}`}>
      <div className="nav-shell">
        <a href="#top" className="brand" aria-label="GrinLuck home" onClick={() => setOpen(false)}>
          <img src="/manus-storage/grinluck-orbit-mark_2eb6808c.png" alt="GrinLuck orbit mark" className="brand-mark" />
          <span>GRIN<span className="brand-accent">LUCK</span></span>
        </a>

        <nav className="nav-links" aria-label="Primary navigation">
          {links.map((link) => (
            <a key={link.href} href={link.href}>{link.label}</a>
          ))}
        </nav>

        <a className="nav-cta" href="#waitlist">
          Join the first orbit <ArrowUpRight size={14} aria-hidden="true" />
        </a>

        <button
          type="button"
          className="menu-button"
          aria-label={open ? "Close navigation" : "Open navigation"}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      <div className={`mobile-panel ${open ? "mobile-panel--open" : ""}`}>
        <nav aria-label="Mobile navigation">
          {links.map((link) => (
            <a key={link.href} href={link.href} onClick={() => setOpen(false)}>{link.label}</a>
          ))}
          <a href="#waitlist" onClick={() => setOpen(false)} className="mobile-join">Join the first orbit <ArrowUpRight size={16} /></a>
        </nav>
      </div>
    </header>
  );
}
