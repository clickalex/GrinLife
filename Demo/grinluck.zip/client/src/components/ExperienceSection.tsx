/**
 * Golden Orbit style reminder: an offset editorial composition with conversation capsules,
 * a vertical orbit thread, and Solar Amber reserved for consent and connection moments.
 */
import { Check, Dice5, HeartHandshake, MessageCircle, Timer, UserRound } from "lucide-react";
import { motion } from "framer-motion";

const steps = [
  { number: "01", title: "Roll", copy: "Enter an active, eligible pool. No browsing. No social score.", icon: Dice5 },
  { number: "02", title: "Spark", copy: "A small shared prompt. Both choose whether to begin.", icon: MessageCircle },
  { number: "03", title: "Talk", copy: "Three private minutes. The clock belongs to both of you.", icon: Timer },
  { number: "04", title: "Choose", copy: "A connection exists only when both people privately say yes.", icon: HeartHandshake },
];

export function ExperienceSection() {
  return (
    <section id="moment" className="section experience-section">
      <div className="orbit-thread" aria-hidden="true"><span /></div>
      <div id="intro" className="section-layout section-layout--intro">
        <div className="section-kicker">01 / The moment</div>
        <div className="intro-copy">
          <p className="lede">A good conversation does not need an algorithm to begin.</p>
          <h2>One roll. One stranger.<br /><em>No performance required.</em></h2>
          <p className="body-copy">GrinLuck removes the usual social signals from the first encounter. You meet as strangers, answer a small prompt, and enter a short conversation only if you both want to.</p>
        </div>
        <aside className="margin-note">
          <span className="margin-note__rule" />
          <p>Profiles do not determine visibility. The first thing you meet is a person willing to talk.</p>
        </aside>
      </div>

      <div className="journey-grid">
        <div className="journey-image-wrap">
          <img src="/manus-storage/grinluck-spark-scene_eaa59e47.png" alt="Two anonymous people connected by a quiet amber thread at night" className="journey-image" />
          <div className="image-caption"><span className="caption-spark" /> A shared prompt before the chat begins</div>
        </div>
        <div className="journey-steps">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.article
                className="journey-step"
                key={step.number}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.45, delay: index * 0.06, ease: [0.23, 1, 0.32, 1] }}
              >
                <div className="step-number">{step.number}</div>
                <div className="step-icon"><Icon size={18} /></div>
                <div><h3>{step.title}</h3><p>{step.copy}</p></div>
              </motion.article>
            );
          })}
        </div>
      </div>

      <div className="spark-preview" aria-label="Spark interaction preview">
        <div className="spark-preview__meta"><span>SPARK / 00:05</span><span>STRANGER</span></div>
        <p className="spark-question">“Describe today in one word.”</p>
        <div className="spark-responses"><span>“Unfolding.”</span><span>“Open.”</span></div>
        <div className="spark-choice"><button type="button"><Check size={15} /> Interested</button><button type="button" className="ghost-choice">Skip</button></div>
        <div className="spark-preview__orbit" aria-hidden="true" />
      </div>
    </section>
  );
}
