/**
 * Golden Orbit style reminder: release stages read as quiet constellation milestones,
 * not product-growth hype; clarity, consent, and safety stay at the center.
 */
import { ArrowUpRight, CircleDot, LockKeyhole, ShieldCheck, TimerReset, WalletCards } from "lucide-react";
import { motion } from "framer-motion";

const phases = [
  { stage: "FIRST ORBIT", title: "Prove the essential encounter", body: "A verified, adult-only, text-first cohort tests anonymous rolls, Sparks, timed chat, mutual connection, and immediate safety controls in one dense pool." },
  { stage: "SECOND WIND", title: "Earn more room for meaning", body: "Memory Capsules, Bottles, translation, and richer Vibe Seeds arrive only when safety response, session quality, and privacy controls are proven." },
  { stage: "WIDER SKY", title: "Grow only when safeguards travel", body: "Broader pools and opt-in group moments come later—after localization, moderation capacity, and reliable matchmaking can scale with care." },
];

const gates = [
  { label: "POOL HEALTH", title: "A real person should be there.", copy: "No geographic expansion until wait times, active density, and conversation quality meet a defined baseline.", icon: TimerReset },
  { label: "SAFETY FIRST", title: "Exit must be instant. Response must be real.", copy: "No richer interaction until block, report, bot defense, and review operations meet clear service targets.", icon: ShieldCheck },
  { label: "PRIVACY BOUNDARY", title: "Ephemeral needs an honest edge.", copy: "Temporary chat stays private by default, with narrow and transparent safety-evidence controls.", icon: LockKeyhole },
  { label: "SUSTAINABLE CARE", title: "Safety cannot be an unfunded promise.", copy: "Growth waits until the cost of moderation, support, and verification can be responsibly carried.", icon: WalletCards },
];

export function RoadmapSection() {
  return (
    <section id="roadmap" className="section roadmap-section">
      <div className="roadmap-topline">
        <div>
          <div className="section-kicker">04 / The road ahead</div>
          <h2>Density before geography.<br /><em>Meaning before metrics.</em></h2>
        </div>
        <p>GrinLuck begins in concentrated pools where a roll can reliably lead to a real person, then expands with care.</p>
      </div>
      <div className="roadmap-line" aria-hidden="true"><span /></div>
      <div className="roadmap-grid">
        {phases.map((phase, index) => (
          <motion.article
            className="roadmap-item"
            key={phase.stage}
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, delay: index * 0.08, ease: [0.23, 1, 0.32, 1] }}
          >
            <CircleDot size={17} className="roadmap-dot" />
            <span className="roadmap-stage">{phase.stage}</span>
            <h3>{phase.title}</h3>
            <p>{phase.body}</p>
          </motion.article>
        ))}
      </div>
      <div className="roadmap-gates">
        <div className="gates-intro">
          <span className="gates-intro__index">THE DISCIPLINE</span>
          <h3>What must be true<br />before we grow.</h3>
          <p>Chance is the invitation. These are the non-negotiables that keep the invitation safe, private, and worth accepting.</p>
        </div>
        <div className="gates-grid">
          {gates.map((gate, index) => {
            const Icon = gate.icon;
            return (
              <motion.article
                className="gate-card"
                key={gate.label}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.4, delay: index * 0.06, ease: [0.23, 1, 0.32, 1] }}
              >
                <div className="gate-card__top"><span>{gate.label}</span><Icon size={16} /></div>
                <h4>{gate.title}</h4>
                <p>{gate.copy}</p>
              </motion.article>
            );
          })}
        </div>
      </div>
      <div id="waitlist" className="join-banner">
        <div><span className="join-banner__eyebrow">OPENING A QUIETER SOCIAL SPACE</span><h2>Roll when you are open<br />to being surprised.</h2></div>
        <a href="mailto:hello@grinluck.com?subject=GrinLuck%20early%20access" className="button button--outline">Request early access <ArrowUpRight size={18} /></a>
      </div>
    </section>
  );
}
