/**
 * Golden Orbit style reminder: avoid generic feature-card grids; use numbered editorial panels
 * with a single restrained amber thread to show the rules that keep chance humane.
 */
import { EyeOff, ShieldCheck, Shuffle, UserRoundCheck } from "lucide-react";
import { motion } from "framer-motion";

const principles = [
  { id: "A", title: "Chance stays chance.", text: "Discovery is randomized. The system may protect safety and availability, but it never ranks people by popularity, appearance, followers, or status.", icon: Shuffle },
  { id: "B", title: "Consent is mutual.", text: "Both people decide independently whether a conversation begins, continues, or becomes a connection. No one is ever told who chose first.", icon: UserRoundCheck },
  { id: "C", title: "Privacy is the default.", text: "Temporary chat is ephemeral. It disappears unless both people choose a Shared Orbit or explicitly preserve a Memory Capsule.", icon: EyeOff },
  { id: "D", title: "Safety has a seat at the table.", text: "Anonymous to strangers never means unaccountable to GrinLuck. Every session includes fast exit, block, report, and real-time safeguards.", icon: ShieldCheck },
];

export function RulesSection() {
  return (
    <section id="rules" className="section rules-section">
      <div className="rules-backdrop" aria-hidden="true" />
      <div className="section-heading section-heading--split">
        <div>
          <div className="section-kicker">02 / The rules</div>
          <h2>Built for serendipity.<br /><em>Bound by consent.</em></h2>
        </div>
        <p>The platform does not decide who you should like. It simply makes space for two people to decide what happens next.</p>
      </div>
      <div className="principle-list">
        {principles.map((principle, index) => {
          const Icon = principle.icon;
          return (
            <motion.article
              key={principle.id}
              className="principle-item"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.45, delay: index * 0.07, ease: [0.23, 1, 0.32, 1] }}
            >
              <span className="principle-id">{principle.id}</span>
              <div className="principle-icon"><Icon size={21} /></div>
              <div className="principle-content"><h3>{principle.title}</h3><p>{principle.text}</p></div>
              <span className="principle-line" aria-hidden="true" />
            </motion.article>
          );
        })}
      </div>
      <blockquote className="golden-rule">
        <span>GRINLUCK’S GOLDEN RULE</span>
        <p>“Does this make people connect because of who they are, or because the system is manipulating visibility?”</p>
      </blockquote>
    </section>
  );
}
