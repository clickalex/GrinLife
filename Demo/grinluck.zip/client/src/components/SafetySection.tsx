/**
 * Golden Orbit style reminder: safety must feel protective and explicit rather than clinical;
 * use the amber capsule image and clear feature architecture to communicate calm control.
 */
import { Ban, Eye, Radio, Shield, TimerReset } from "lucide-react";
import { motion } from "framer-motion";

const safeguards = [
  { title: "Vanish without explanation", description: "Leave a conversation instantly. The other person is never told why.", icon: Ban },
  { title: "Anonymous, not unaccountable", description: "The platform verifies and protects the service while keeping strangers unknown to each other.", icon: Eye },
  { title: "Real-time safety response", description: "Risk-aware moderation can warn, end a session, restrict an account, or escalate for review.", icon: Radio },
  { title: "A clock that protects choice", description: "Server-authoritative timers, one optional Second Wind, and graceful reconnection handling.", icon: TimerReset },
];

export function SafetySection() {
  return (
    <section id="safety" className="section safety-section">
      <div className="safety-layout">
        <div className="safety-visual">
          <img src="/manus-storage/grinluck-safety-scene_68a75faa.png" alt="An amber conversation capsule protected by translucent rings" />
          <div className="safety-seal"><Shield size={18} /><span>SAFE BY DESIGN</span></div>
        </div>
        <div className="safety-copy">
          <div className="section-kicker">03 / The protection</div>
          <h2>Private to strangers.<br /><em>Present when it matters.</em></h2>
          <p className="body-copy">GrinLuck is built around a simple line: anonymous to strangers, accountable to GrinLuck. Every encounter has immediate exits, clear consent, and safeguards that do not turn safety into social surveillance.</p>
          <div className="safeguard-list">
            {safeguards.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  className="safeguard"
                  key={item.title}
                  initial={{ opacity: 0, x: 16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{ duration: 0.4, delay: index * 0.06, ease: [0.23, 1, 0.32, 1] }}
                >
                  <Icon size={17} /><div><h3>{item.title}</h3><p>{item.description}</p></div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
