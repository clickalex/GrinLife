/**
 * Golden Orbit style reminder: the hero holds generous negative space on the left;
 * the generated nocturnal orbit image stays quiet behind calm, human-scale typography.
 */
import { ArrowDown, Dice5, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export function HeroSection() {
  return (
    <section id="top" className="hero-section">
      <div className="hero-image" aria-hidden="true" />
      <div className="hero-shade" aria-hidden="true" />
      <div className="hero-orbit hero-orbit--one" aria-hidden="true" />
      <div className="hero-orbit hero-orbit--two" aria-hidden="true" />
      <div className="hero-grain" aria-hidden="true" />

      <div className="hero-content">
        <motion.div
          className="eyebrow eyebrow--light"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
        >
          <span className="eyebrow-dot" /> A different kind of social space
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, delay: 0.05, ease: [0.23, 1, 0.32, 1] }}
        >
          Meet by chance.<br />
          <em>Stay by choice.</em>
        </motion.h1>

        <motion.p
          className="hero-copy"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.12, ease: [0.23, 1, 0.32, 1] }}
        >
          GrinLuck is an anonymous, consent-led way to meet someone interesting—without profiles,
          followers, or an algorithm deciding who deserves to be seen.
        </motion.p>

        <motion.div
          className="hero-actions"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.2, ease: [0.23, 1, 0.32, 1] }}
        >
          <a href="#moment" className="button button--amber"><Dice5 size={19} /> See how a roll works</a>
          <a href="#rules" className="text-link">Read the philosophy <span>→</span></a>
        </motion.div>
      </div>

      <motion.div
        className="hero-note"
        initial={{ opacity: 0, x: 18 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.35, ease: [0.23, 1, 0.32, 1] }}
      >
        <Sparkles size={15} aria-hidden="true" />
        <span><strong>Pure luck.</strong> Protected by safety, not popularity.</span>
      </motion.div>

      <a href="#intro" className="scroll-cue" aria-label="Scroll to discover GrinLuck">
        <span>Discover the premise</span><ArrowDown size={16} />
      </a>
    </section>
  );
}
