/*
 * FooterSection — Timeless Void design with enhanced brand presence
 * CTA section with cinematic glow + footer with strong brand identity
 */
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { ArrowRight } from "lucide-react";

function CTASection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="contact" className="relative py-28 lg:py-36 overflow-hidden">
      {/* Memory thread */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1px] h-full bg-gradient-to-b from-[#F5A623]/20 via-[#F5A623]/40 to-[#F5A623]/10" />

      {/* Background glow */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#F5A623]/5 rounded-full blur-[120px]" />
        <div className="absolute top-1/3 left-1/4 w-[300px] h-[300px] bg-[#6C63FF]/3 rounded-full blur-[80px]" />
      </div>

      <div className="container max-w-4xl mx-auto px-4 text-center relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
        >
          <p className="font-accent italic text-[#F5A623] text-lg mb-3">Begin Your Legacy</p>
          <h2 className="font-display text-3xl lg:text-5xl font-bold text-[#F1EDED] mb-6">
            Your story has no expiration date
          </h2>
          <p className="text-[#9BA3B2] text-lg max-w-xl mx-auto mb-10 leading-relaxed">
            Join the growing community of individuals and families preserving their
            digital legacy with AI, blockchain, and physical archival technology.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="#"
              className="px-8 py-3.5 rounded-lg bg-[#F5A623] text-[#0A0B0F] font-semibold text-sm hover:bg-[#FFC04A] transition-all duration-200 active:scale-[0.97] shadow-lg shadow-[#F5A623]/20 inline-flex items-center gap-2"
            >
              Get Early Access <ArrowRight size={16} />
            </a>
            <a
              href="#"
              className="px-8 py-3.5 rounded-lg border border-white/10 text-[#F1EDED] font-medium text-sm hover:bg-white/5 hover:border-white/20 transition-all duration-200"
            >
              Schedule a Demo
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="relative border-t border-white/5 py-14">
      {/* Top amber thread */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#F5A623]/30 to-transparent" />

      <div className="container max-w-6xl mx-auto px-4">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand — more prominent */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <img
                src="/manus-storage/grinrex-logo_5402f707.png"
                alt="Grinrex"
                className="w-9 h-9 drop-shadow-[0_0_8px_rgba(245,166,35,0.3)]"
              />
              <span className="font-display text-xl font-bold text-gradient-gold">
                Grinrex
              </span>
            </div>
            <p className="text-[#9BA3B2] text-sm leading-relaxed">
              The world's most trusted platform for preserving human memories across generations.
            </p>
          </div>

          {/* Platform */}
          <div>
            <h4 className="font-display text-sm font-semibold text-[#F1EDED] mb-4">Platform</h4>
            <ul className="space-y-2.5">
              {["Memory Vault", "AI Biography", "Time Capsule", "Digital Will"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-[#9BA3B2] text-sm hover:text-[#F5A623] transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-display text-sm font-semibold text-[#F1EDED] mb-4">Company</h4>
            <ul className="space-y-2.5">
              {["About Us", "Careers", "Blog", "Press Kit"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-[#9BA3B2] text-sm hover:text-[#F5A623] transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-display text-sm font-semibold text-[#F1EDED] mb-4">Legal</h4>
            <ul className="space-y-2.5">
              {["Privacy Policy", "Terms of Service", "Security", "GDPR"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-[#9BA3B2] text-sm hover:text-[#F5A623] transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[#9BA3B2] text-xs">
            &copy; {new Date().getFullYear()} Grinrex. All rights reserved.
          </p>
          <p className="text-[#9BA3B2] text-xs">
            Preserving humanity's stories, one memory at a time.
          </p>
        </div>
      </div>
    </footer>
  );
}

export { CTASection, Footer };
