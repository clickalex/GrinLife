/*
 * UsersSection — Timeless Void design
 * Target audience with icon-based cards
 */
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import {
  User,
  Users,
  GraduationCap,
  Landmark,
  BookMarked,
  ShieldCheck,
  Heart,
  Briefcase,
  LandPlot,
} from "lucide-react";

const users = [
  { icon: User, label: "Individuals", desc: "Preserve your personal story and values" },
  { icon: Users, label: "Families", desc: "Build collaborative family histories across generations" },
  { icon: Briefcase, label: "Professionals", desc: "Document career achievements and professional legacy" },
  { icon: Landmark, label: "Historians", desc: "Archive and verify historical narratives" },
  { icon: BookMarked, label: "Authors", desc: "Create AI-assisted autobiographies and memoirs" },
  { icon: ShieldCheck, label: "Military", desc: "Preserve service records and personal experiences" },
  { icon: Heart, label: "Senior Citizens", desc: "Capture lifetime of memories for future generations" },
  { icon: GraduationCap, label: "Parents", desc: "Pass down values, stories, and wisdom to children" },
  { icon: LandPlot, label: "Genealogists", desc: "Research and document family heritage with verified records" },
];

export default function UsersSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section className="relative py-24 lg:py-32">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#F5A623]/20 to-transparent" />

      <div className="container max-w-6xl mx-auto px-4" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-accent italic text-[#F5A623] text-lg mb-3">Who It's For</p>
          <h2 className="font-display text-3xl lg:text-5xl font-bold text-[#F1EDED] mb-4">
            Everyone has a legacy worth preserving
          </h2>
          <p className="text-[#9BA3B2] text-lg max-w-2xl mx-auto">
            Grinrex serves anyone who believes their story matters — from individuals to institutions.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {users.map((user, i) => (
            <motion.div
              key={user.label}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="glass-card rounded-xl p-5 flex items-start gap-4 group hover:amber-glow transition-all duration-300"
            >
              <div className="w-10 h-10 rounded-lg bg-[#F5A623]/8 flex items-center justify-center flex-shrink-0 group-hover:bg-[#F5A623]/15 transition-colors duration-300">
                <user.icon size={18} className="text-[#F5A623]" />
              </div>
              <div>
                <h3 className="font-display text-sm font-semibold text-[#F1EDED] mb-1">
                  {user.label}
                </h3>
                <p className="text-[#9BA3B2] text-sm">{user.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
