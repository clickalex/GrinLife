/*
 * HeroSection — Timeless Void design with cinematic narrative
 * Enhanced with memory thread motif and dramatic typography
 */
import { motion } from "framer-motion";
import { ArrowDown } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/manus-storage/grinrex-hero-bg_b410b7fe.png"
          alt=""
          className="w-full h-full object-cover"
        />
        {/* Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A0B0F]/30 via-[#0A0B0F]/50 to-[#0A0B0F]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0B0F]/60 to-transparent" />
      </div>

      {/* Memory Thread — vertical amber line descending from hero */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[1px] h-24 bg-gradient-to-t from-[#F5A623]/40 to-transparent z-20" />

      {/* Content */}
      <div className="relative z-10 container text-center max-w-4xl mx-auto px-4 pt-28 pb-36">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-[#9BA3B2] text-sm lg:text-base font-medium tracking-[0.2em] uppercase mb-6"
        >
          The Hybrid Digital-to-Physical Legacy Ecosystem
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.08] mb-6"
        >
          <span className="text-[#F1EDED]">Your story deserves</span>
          <br />
          <span className="text-gradient-gold text-shadow-glow">more than a hard drive</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="text-[#9BA3B2] text-lg lg:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          Preserve, organize, and pass on your memories, knowledge, digital assets,
          and family heritage across generations. Powered by AI, secured by
          blockchain, and preserved in both digital and physical form.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href="#features"
            className="px-8 py-3.5 rounded-lg bg-[#F5A623] text-[#0A0B0F] font-semibold text-sm hover:bg-[#FFC04A] transition-all duration-200 active:scale-[0.97] shadow-lg shadow-[#F5A623]/20"
          >
            Explore the Platform
          </a>
          <a
            href="#about"
            className="px-8 py-3.5 rounded-lg border border-white/10 text-[#F1EDED] font-medium text-sm hover:bg-white/5 hover:border-white/20 transition-all duration-200"
          >
            Learn More
          </a>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        >
          <ArrowDown size={20} className="text-[#9BA3B2]/60" />
        </motion.div>
      </motion.div>
    </section>
  );
}
