/*
 * RoadmapSection — Timeless Void design
 * Vertical timeline with phase indicators
 */
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Check } from "lucide-react";

const phases = [
  {
    phase: "Phase 1",
    title: "Foundation",
    desc: "Authentication, memory vault, user profiles, and core infrastructure",
    status: "current",
  },
  {
    phase: "Phase 2",
    title: "AI & Intelligence",
    desc: "AI organization, timeline creation, semantic search, and biography generation",
    status: "upcoming",
  },
  {
    phase: "Phase 3",
    title: "Family & Inheritance",
    desc: "Family collaboration, digital will execution, and controlled legacy transfer",
    status: "upcoming",
  },
  {
    phase: "Phase 4",
    title: "Physical & Blockchain",
    desc: "Physical legacy products and blockchain verification for authenticity",
    status: "upcoming",
  },
  {
    phase: "Phase 5",
    title: "Global Expansion",
    desc: "Multilingual support, enterprise offerings, and institutional legacy management",
    status: "upcoming",
  },
];

export default function RoadmapSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="roadmap" className="relative py-24 lg:py-32">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#F5A623]/20 to-transparent" />

      <div className="container max-w-4xl mx-auto px-4" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-accent italic text-[#F5A623] text-lg mb-3">Development Roadmap</p>
          <h2 className="font-display text-3xl lg:text-5xl font-bold text-[#F1EDED] mb-4">
            Building the future
          </h2>
          <p className="text-[#9BA3B2] text-lg max-w-2xl mx-auto">
            A phased approach to building the most comprehensive legacy ecosystem ever created.
          </p>
        </motion.div>

        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-6 lg:left-8 top-0 bottom-0 w-[1px] bg-gradient-to-b from-[#F5A623]/60 via-[#F5A623]/20 to-transparent" />

          <div className="space-y-8">
            {phases.map((phase, i) => (
              <motion.div
                key={phase.phase}
                initial={{ opacity: 0, x: -20 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.5, delay: i * 0.12 }}
                className="flex gap-6 lg:gap-8"
              >
                {/* Dot */}
                <div className="relative flex-shrink-0 mt-1">
                  <div
                    className={`w-12 h-12 lg:w-16 lg:h-16 rounded-full flex items-center justify-center border-2 ${
                      phase.status === "current"
                        ? "border-[#F5A623] bg-[#F5A623]/10"
                        : "border-white/10 bg-white/5"
                    }`}
                  >
                    {phase.status === "current" ? (
                      <Check size={16} className="text-[#F5A623]" />
                    ) : (
                      <span className="text-[#9BA3B2] text-xs font-medium font-display">
                        {phase.phase.replace("Phase ", "")}
                      </span>
                    )}
                  </div>
                </div>

                {/* Content */}
                <div className="pb-4">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-[#F5A623] text-xs font-medium tracking-wider uppercase">
                      {phase.phase}
                    </span>
                    {phase.status === "current" && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-[#F5A623]/10 text-[#F5A623] border border-[#F5A623]/20">
                        In Progress
                      </span>
                    )}
                  </div>
                  <h3 className="font-display text-xl font-semibold text-[#F1EDED] mb-2">
                    {phase.title}
                  </h3>
                  <p className="text-[#9BA3B2] text-sm leading-relaxed">{phase.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
