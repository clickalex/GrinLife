/*
 * FeaturesSection — Timeless Void design with memory thread motif
 * Alternating cinematic layout — featured hero feature + compact grid
 */
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import {
  BrainCircuit,
  HardDrive,
  BookOpen,
  Users,
  FileLock2,
  Timer,
  MessageSquareText,
  Gem,
} from "lucide-react";

const features = [
  {
    icon: BrainCircuit,
    title: "AI Biography Builder",
    desc: "Intelligent memory organization with automatic tagging, timeline creation, and AI-powered autobiography generation from your life's moments.",
  },
  {
    icon: HardDrive,
    title: "Digital Memory Vault",
    desc: "Secure, encrypted storage for photos, videos, audio, documents, and journals — organized intelligently and accessible across generations.",
  },
  {
    icon: BookOpen,
    title: "Physical Legacy Store",
    desc: "Transform digital memories into archival-quality books, engraved drives, keepsake boxes, and memory capsules with lasting physical form.",
  },
  {
    icon: Users,
    title: "Family Collaboration",
    desc: "Controlled sharing with role-based access, collaborative editing, comments, and family tree integration across generations.",
  },
  {
    icon: FileLock2,
    title: "Digital Inheritance",
    desc: "Trusted contacts, inheritance rules, digital will execution, and posthumous access controls ensuring your legacy reaches the right people.",
  },
  {
    icon: Timer,
    title: "Time Capsule",
    desc: "Schedule messages, memories, and digital assets to be unlocked at specific dates — delivering memories across time to future generations.",
  },
  {
    icon: MessageSquareText,
    title: "Legacy Storytelling",
    desc: "AI-powered narrative generation transforms scattered memories into cohesive, compelling stories that preserve your voice and values.",
  },
  {
    icon: Gem,
    title: "Blockchain Verification",
    desc: "Immutable proof of authenticity, timestamped records, and certified ownership — ensuring your legacy cannot be altered or disputed.",
  },
];

export default function FeaturesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="features" className="relative py-28 lg:py-36">
      {/* Memory thread — vertical amber line through section */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1px] h-full bg-gradient-to-b from-[#F5A623]/20 via-[#F5A623]/10 to-transparent" />

      <div className="container max-w-6xl mx-auto px-4 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <p className="font-accent italic text-[#F5A623] text-lg mb-3">Platform Features</p>
          <h2 className="font-display text-3xl lg:text-5xl font-bold text-[#F1EDED] mb-4">
            Built for eternity
          </h2>
          <p className="text-[#9BA3B2] text-lg max-w-2xl mx-auto">
            Every feature designed with one purpose — ensuring your legacy endures beyond time.
          </p>
        </motion.div>

        {/* Top two featured cards — larger, cinematic */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {features.slice(0, 2).map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.12 }}
              className="glass-card rounded-2xl p-8 group hover:amber-glow transition-all duration-300 relative overflow-hidden"
            >
              {/* Ambient glow */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#F5A623]/5 rounded-full blur-[60px] group-hover:bg-[#F5A623]/10 transition-colors duration-500" />
              <div className="relative z-10">
                <div className="w-12 h-12 rounded-xl bg-[#F5A623]/10 flex items-center justify-center mb-5 group-hover:bg-[#F5A623]/20 transition-colors duration-300">
                  <feature.icon size={24} className="text-[#F5A623]" />
                </div>
                <h3 className="font-display text-xl font-semibold text-[#F1EDED] mb-3">
                  {feature.title}
                </h3>
                <p className="text-[#9BA3B2] text-sm leading-relaxed">{feature.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom six — compact grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.slice(2).map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: 0.2 + i * 0.06 }}
              className="glass-card rounded-xl p-5 group hover:amber-glow transition-all duration-300"
            >
              <div className="w-9 h-9 rounded-lg bg-[#F5A623]/10 flex items-center justify-center mb-3 group-hover:bg-[#F5A623]/20 transition-colors duration-300">
                <feature.icon size={18} className="text-[#F5A623]" />
              </div>
              <h3 className="font-display text-sm font-semibold text-[#F1EDED] mb-2">
                {feature.title}
              </h3>
              <p className="text-[#9BA3B2] text-sm leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
