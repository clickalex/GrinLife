/*
 * Navbar — Timeless Void design with elevated brand presence
 */
import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "About", href: "#about" },
    { label: "Features", href: "#features" },
    { label: "Modules", href: "#modules" },
    { label: "Pricing", href: "#pricing" },
    { label: "Roadmap", href: "#roadmap" },
    { label: "Connect", href: "#contact" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#0A0B0F]/85 backdrop-blur-xl border-b border-white/5"
          : "bg-transparent"
      }`}
    >
      <nav className="container flex items-center justify-between h-18 lg:h-22">
        {/* Logo — larger and more prominent */}
        <a href="#" className="flex items-center gap-3 group">
          <img
            src="/manus-storage/grinrex-logo_5402f707.png"
            alt="Grinrex"
            className="w-10 h-10 lg:w-11 lg:h-11 transition-transform duration-300 group-hover:scale-110 drop-shadow-[0_0_12px_rgba(245,166,35,0.4)]"
          />
          <span className="font-display text-2xl font-bold text-gradient-gold tracking-tight">
            Grinrex
          </span>
        </a>

        {/* Desktop Nav */}
        <ul className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-sm font-medium text-[#9BA3B2] hover:text-[#F5A623] transition-colors duration-200 relative after:absolute after:bottom-[-4px] after:left-0 after:h-[1px] after:w-0 after:bg-[#F5A623] after:transition-all after:duration-300 hover:after:w-full"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        {/* CTA Button */}
        <a
          href="#contact"
          className="hidden lg:inline-flex items-center px-6 py-2.5 rounded-lg bg-[#F5A623]/10 border border-[#F5A623]/30 text-[#F5A623] text-sm font-medium hover:bg-[#F5A623]/20 hover:border-[#F5A623]/50 transition-all duration-300"
        >
          Begin Your Legacy
        </a>

        {/* Mobile Menu Toggle */}
        <button
          className="lg:hidden text-[#F1EDED] p-2"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
            className="lg:hidden bg-[#0A0B0F]/95 backdrop-blur-xl border-b border-white/5 overflow-hidden"
          >
            <ul className="container py-4 flex flex-col gap-3">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="block py-2 text-[#9BA3B2] hover:text-[#F5A623] text-sm font-medium transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <a
                  href="#contact"
                  onClick={() => setMobileOpen(false)}
                  className="inline-flex items-center px-6 py-2.5 rounded-lg bg-[#F5A623]/10 border border-[#F5A623]/30 text-[#F5A623] text-sm font-medium"
                >
                  Begin Your Legacy
                </a>
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
