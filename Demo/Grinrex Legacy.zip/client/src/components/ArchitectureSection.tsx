/*
 * ArchitectureSection — Timeless Void design with memory thread
 * Layered architecture with constellation-style connections
 */
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Monitor, Layers, Brain, Database } from "lucide-react";

const layers = [
  {
    icon: Monitor,
    title: "Client Layer",
    items: ["Web Application", "Mobile Application", "Admin Portal", "Family Portal"],
    color: "from-[#F5A623]/20 to-[#F5A623]/5",
  },
  {
    icon: Layers,
    title: "Application Layer",
    items: ["Auth Service", "Memory Service", "AI Service", "Legacy Service", "Blockchain Service"],
    color: "from-[#6C63FF]/20 to-[#6C63FF]/5",
  },
  {
    icon: Brain,
    title: "AI Layer",
    items: ["Memory Classification", "Face Recognition", "Biography Generation", "Semantic Search"],
    color: "from-[#4ECDC4]/20 to-[#4ECDC4]/5",
  },
  {
    icon: Database,
    title: "Data Layer",
    items: ["PostgreSQL", "Object Storage", "Vector DB", "Blockchain Records", "Cache Layer"],
    color: "from-[#F5A623]/15 to-[#F5A623]/3",
  },
];

export default function ArchitectureSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section className="relative py-28 lg:py-36">
      {/* Memory thread */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1px] h-full bg-gradient-to-b from-[#F5A623]/20 via-[#F5A623]/10 to-transparent" />

      <div className="container max-w-5xl mx-auto px-4 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-accent italic text-[#F5A623] text-lg mb-3">Technical Architecture</p>
          <h2 className="font-display text-3xl lg:text-5xl font-bold text-[#F1EDED] mb-4">
            Engineered for scale & security
          </h2>
          <p className="text-[#9BA3B2] text-lg max-w-2xl mx-auto">
            A microservices architecture built on zero-trust principles with end-to-end encryption.
          </p>
        </motion.div>

        <div className="grid gap-4">
          {layers.map((layer, i) => (
            <motion.div
              key={layer.title}
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="glass-card rounded-xl p-5 lg:p-6 flex flex-col lg:flex-row lg:items-center gap-4 lg:gap-8 group hover:border-white/12 transition-all duration-300 relative"
            >
              {/* Connecting dot on left */}
              <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[2px] h-8 bg-[#F5A623]/30 rounded-full" />
              <div className="flex items-center gap-4 lg:w-56 flex-shrink-0">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${layer.color} flex items-center justify-center`}>
                  <layer.icon size={18} className="text-[#F1EDED]" />
                </div>
                <h3 className="font-display text-base font-semibold text-[#F1EDED]">
                  {layer.title}
                </h3>
              </div>
              <div className="flex flex-wrap gap-2 lg:flex-1">
                {layer.items.map((item) => (
                  <span
                    key={item}
                    className="px-3 py-1 rounded-md text-xs font-medium bg-white/5 text-[#9BA3B2] border border-white/5"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Security highlights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-12 grid sm:grid-cols-3 gap-4"
        >
          {[
            { label: "End-to-End Encryption", desc: "Zero Trust architecture" },
            { label: "RBAC & ABAC", desc: "Granular access control" },
            { label: "Immutable Audit Logs", desc: "Complete transparency" },
          ].map((item, i) => (
            <div key={item.label} className="text-center p-4 glass-card rounded-xl">
              <p className="text-[#F1EDED] font-semibold text-sm mb-1">{item.label}</p>
              <p className="text-[#9BA3B2] text-xs">{item.desc}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
