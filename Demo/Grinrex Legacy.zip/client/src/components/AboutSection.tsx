/*
 * AboutSection — Timeless Void design with memory thread motif
 * Enhanced with constellation-like amber lines connecting content
 */
import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Shield, Brain, Lock, Clock } from "lucide-react";

const stats = [
  { icon: Shield, label: "Secure Vault", desc: "End-to-end encryption" },
  { icon: Brain, label: "AI-Powered", desc: "Intelligent organization" },
  { icon: Lock, label: "Blockchain", desc: "Immutable verification" },
  { icon: Clock, label: "Perpetual", desc: "Lifetime preservation" },
];

export default function AboutSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="relative py-28 lg:py-36">
      {/* Memory thread — vertical amber line */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1px] h-full bg-gradient-to-b from-[#F5A623]/30 via-[#F5A623]/10 to-transparent" />

      <div className="container max-w-6xl mx-auto px-4 relative z-10" ref={ref}>
        {/* Stats Grid — constellation style */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-24"
        >
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="glass-card rounded-xl p-6 text-center group hover:amber-glow transition-all duration-300 relative"
            >
              {/* Connecting dot */}
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-[#F5A623]/60" />
              <stat.icon size={22} className="text-[#F5A623] mx-auto mb-3" />
              <p className="text-[#F1EDED] font-semibold text-sm mb-1">{stat.label}</p>
              <p className="text-[#9BA3B2] text-xs">{stat.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Problem & Vision — cinematic two-column with amber thread between */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start relative">
          {/* Horizontal thread */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-[1px] bg-gradient-to-r from-[#F5A623]/20 via-[#F5A623]/40 to-[#F5A623]/20 -translate-y-1/2" />

          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="relative z-10"
          >
            <p className="font-accent italic text-[#F5A623] text-lg mb-4">The Problem</p>
            <h2 className="font-display text-3xl lg:text-4xl font-bold text-[#F1EDED] mb-6 leading-[1.15]">
              Digital memories are vanishing
            </h2>
            <p className="text-[#9BA3B2] leading-relaxed mb-4">
              Modern digital information is scattered across numerous platforms — cloud
              storage, social media, messaging apps, and email services. Over time, data
              is forgotten, inaccessible, or permanently lost due to account deletion,
              changing technologies, or lack of succession planning.
            </p>
            <p className="text-[#9BA3B2] leading-relaxed">
              There is currently no unified platform that securely preserves an
              individual's complete digital legacy while providing controlled inheritance,
              AI-powered storytelling, and physical archival options.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="glass-card rounded-2xl p-8 lg:p-10 relative z-10"
          >
            <p className="font-accent italic text-[#F5A623] text-lg mb-4">Our Vision</p>
            <h3 className="font-display text-2xl lg:text-3xl font-bold text-[#F1EDED] mb-6">
              The world's most trusted platform for preserving human memories
            </h3>
            <p className="text-[#9BA3B2] leading-relaxed mb-6">
              Grinrex combines AI, blockchain, secure cloud infrastructure, and physical
              preservation technologies into a single platform that ensures a person's
              legacy remains accessible long after their lifetime.
            </p>
            <div className="flex flex-wrap gap-2">
              {["AI", "Blockchain", "Cloud", "Physical Archival"].map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 rounded-full text-xs font-medium bg-[#F5A623]/10 text-[#F5A623] border border-[#F5A623]/20"
                >
                  {tag}
                </span>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
