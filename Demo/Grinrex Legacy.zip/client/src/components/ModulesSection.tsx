/*
 * ModulesSection — Timeless Void design with memory thread
 * Alternating image/text with horizontal amber thread connectors
 */
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const modules = [
  {
    image: "/manus-storage/grinrex-vault_0ea8f6c4.png",
    title: "Digital Memory Vault",
    description:
      "Your secure digital sanctuary. Upload, categorize, tag, and organize photos, videos, audio, documents, and journals. AI automatically creates timelines, detects duplicates, and suggests connections between memories.",
    features: ["Encrypted Storage", "AI Auto-Tagging", "Semantic Search", "Timeline Builder"],
  },
  {
    image: "/manus-storage/grinrex-family_33833a2c.png",
    title: "Family Collaboration",
    description:
      "Connect generations through shared memories. Role-based access controls allow family members to contribute, comment, and build collaborative family histories while respecting privacy boundaries.",
    features: ["Role-Based Access", "Shared Timeline", "Collaborative Editing", "Family Tree"],
  },
  {
    image: "/manus-storage/grinrex-physical_c1edb3bc.png",
    title: "Physical Legacy Store",
    description:
      "Bridge the digital and physical worlds. Order archival-quality books, engraved storage devices, memory capsules, and custom keepsakes — all generated from your digital content with museum-grade quality.",
    features: ["Archival Books", "Engraved Drives", "Memory Capsules", "Custom Keepsakes"],
  },
  {
    image: "/manus-storage/grinrex-ai_f92aaa10.png",
    title: "AI-Powered Intelligence",
    description:
      "Let AI transform your raw memories into compelling narratives. From biography generation to relationship mapping, from voice processing to natural language search — your legacy becomes effortlessly accessible.",
    features: ["Biography Generator", "Face Recognition", "Voice Processing", "OCR & Document Understanding"],
  },
];

export default function ModulesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="modules" className="relative py-28 lg:py-36">
      {/* Memory thread — vertical amber line */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1px] h-full bg-gradient-to-b from-[#F5A623]/20 via-[#F5A623]/10 to-transparent" />

      <div className="container max-w-6xl mx-auto px-4 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <p className="font-accent italic text-[#F5A623] text-lg mb-3">Core Modules</p>
          <h2 className="font-display text-3xl lg:text-5xl font-bold text-[#F1EDED] mb-4">
            An ecosystem of preservation
          </h2>
          <p className="text-[#9BA3B2] text-lg max-w-2xl mx-auto">
            Sixteen integrated modules working in harmony to protect, organize, and transmit your legacy.
          </p>
        </motion.div>

        <div className="space-y-24 lg:space-y-32">
          {modules.map((module, i) => (
            <motion.div
              key={module.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: i * 0.15 }}
              className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center"
            >
              {/* Image */}
              <div className={`relative rounded-2xl overflow-hidden ${i % 2 === 1 ? "lg:order-2" : ""}`}>
                <img
                  src={module.image}
                  alt={module.title}
                  className="w-full h-64 lg:h-[340px] object-cover rounded-2xl"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0B0F]/70 to-transparent rounded-2xl" />
                {/* Amber corner accent */}
                <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#F5A623]/40 to-transparent" />
              </div>

              {/* Content */}
              <div className={i % 2 === 1 ? "lg:order-1" : ""}>
                <h3 className="font-display text-2xl lg:text-3xl font-bold text-[#F1EDED] mb-4">
                  {module.title}
                </h3>
                <p className="text-[#9BA3B2] leading-relaxed mb-6">{module.description}</p>
                <div className="flex flex-wrap gap-2">
                  {module.features.map((f) => (
                    <span
                      key={f}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 text-[#F1EDED] border border-white/8"
                    >
                      {f}
                    </span>
                  ))}
                </div>
              </div>

              {/* Horizontal thread connector between image and text */}
              <div className="hidden lg:block absolute left-1/2 top-1/2 w-16 h-[1px] bg-[#F5A623]/20" style={{ display: 'none' }} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
