/*
 * PricingSection — Timeless Void design
 * Three-tier pricing with cinematic amber-gold accents and memory thread motif
 */
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Check, Sparkles, Users, Building2, ArrowRight } from "lucide-react";

const tiers = [
  {
    icon: Sparkles,
    name: "Individual",
    tagline: "For those preserving their own legacy",
    price: "$9",
    period: "/month",
    description: "Everything you need to safeguard your memories, generate your biography, and preserve your story for generations to come.",
    features: [
      "50 GB secure memory vault",
      "AI biography generation",
      "Timeline builder & organization",
      "1 time capsule",
      "Basic physical keepsake access",
      "Blockchain authenticity certificate",
      "Priority support",
    ],
    cta: "Start Preserving",
    featured: false,
  },
  {
    icon: Users,
    name: "Family",
    tagline: "For families building shared heritage",
    price: "$24",
    period: "/month",
    description: "Connect generations through collaborative memory preservation. Build your family's collective story with shared vaults and controlled inheritance.",
    features: [
      "500 GB shared family vault",
      "Up to 8 family members",
      "Full AI biography suite",
      "Family tree integration",
      "Digital will & inheritance tools",
      "Unlimited time capsules",
      "Physical legacy ordering",
      "Role-based access controls",
      "Priority support",
    ],
    cta: "Protect Your Family's Story",
    featured: true,
  },
  {
    icon: Building2,
    name: "Enterprise",
    tagline: "For organizations preserving institutional knowledge",
    price: "Custom",
    period: "",
    description: "Tailored legacy preservation for organizations, institutions, and enterprises. Custom storage, dedicated support, and advanced compliance features.",
    features: [
      "Unlimited storage",
      "Unlimited users & collaborators",
      "Custom AI training on your data",
      "Institutional archive management",
      "Advanced compliance & audit",
      "Dedicated account manager",
      "Custom physical archival products",
      "API access & integrations",
      "SLA guarantee",
      "On-premise deployment option",
    ],
    cta: "Contact Sales",
    featured: false,
  },
];

export default function PricingSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="pricing" className="relative py-28 lg:py-36">
      {/* Memory thread */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1px] h-full bg-gradient-to-b from-[#F5A623]/20 via-[#F5A623]/10 to-transparent" />

      <div className="container max-w-6xl mx-auto px-4 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-accent italic text-[#F5A623] text-lg mb-3">Pricing</p>
          <h2 className="font-display text-3xl lg:text-5xl font-bold text-[#F1EDED] mb-4">
            Choose how your legacy lives on
          </h2>
          <p className="text-[#9BA3B2] text-lg max-w-2xl mx-auto">
            Every plan includes core preservation tools. Upgrade as your legacy grows.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6 items-start">
          {tiers.map((tier, i) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.12 }}
              className={`relative rounded-2xl p-6 lg:p-8 transition-all duration-300 ${
                tier.featured
                  ? "glass-card border-[#F5A623]/20 hover:border-[#F5A623]/40 amber-glow lg:scale-105 lg:-mt-4 lg:mb-4"
                  : "glass-card hover:border-white/12"
              }`}
            >
              {/* Featured badge */}
              {tier.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-[#F5A623] text-[#0A0B0F] text-xs font-semibold">
                  Most Popular
                </div>
              )}

              {/* Icon & Title */}
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  tier.featured ? "bg-[#F5A623]/15" : "bg-white/5"
                }`}>
                  <tier.icon size={18} className={tier.featured ? "text-[#F5A623]" : "text-[#9BA3B2]"} />
                </div>
                <div>
                  <h3 className="font-display text-lg font-semibold text-[#F1EDED]">{tier.name}</h3>
                  <p className="text-[#9BA3B2] text-xs">{tier.tagline}</p>
                </div>
              </div>

              {/* Price */}
              <div className="mb-5">
                <div className="flex items-baseline gap-1">
                  <span className={`font-display text-4xl font-bold ${tier.featured ? "text-[#F5A623]" : "text-[#F1EDED]"}`}>
                    {tier.price}
                  </span>
                  {tier.period && (
                    <span className="text-[#9BA3B2] text-sm">{tier.period}</span>
                  )}
                </div>
                <p className="text-[#9BA3B2] text-sm mt-2 leading-relaxed">{tier.description}</p>
              </div>

              {/* Features */}
              <ul className="space-y-2.5 mb-8">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2.5">
                    <Check size={14} className={`mt-0.5 flex-shrink-0 ${tier.featured ? "text-[#F5A623]" : "text-[#6C63FF]"}`} />
                    <span className="text-[#9BA3B2] text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <a
                href="#"
                className={`w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold transition-all duration-200 active:scale-[0.97] ${
                  tier.featured
                    ? "bg-[#F5A623] text-[#0A0B0F] hover:bg-[#FFC04A] shadow-lg shadow-[#F5A623]/20"
                    : "border border-white/10 text-[#F1EDED] hover:bg-white/5 hover:border-white/20"
                }`}
              >
                {tier.cta} <ArrowRight size={14} />
              </a>
            </motion.div>
          ))}
        </div>

        {/* Bottom note */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="text-center text-[#9BA3B2] text-sm mt-10"
        >
          All plans include end-to-end encryption, blockchain verification, and a 30-day money-back guarantee.
        </motion.p>
      </div>
    </section>
  );
}
