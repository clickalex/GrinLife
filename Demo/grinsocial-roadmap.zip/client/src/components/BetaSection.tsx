/* Timeless Void: the CTA closes with a human invitation, not a growth-hack promise. */
import { ArrowRight, Check, Mail, Sparkles } from 'lucide-react';

const nextSteps = [
  'Confirm Phase 0–1 timeline and resourcing with engineering and design.',
  'Validate the matching algorithm against a sample preference dataset.',
  'Complete legal review of location handling and messaging retention.',
  'Recruit a 500–1,000 person beta cohort to test matching quality and auto-leave UX.',
];

export default function BetaSection() {
  return (
    <section id="beta" className="relative overflow-hidden bg-[#0A0B0F] section-py">
      <div className="absolute right-[-10rem] top-1/2 h-[30rem] w-[30rem] -translate-y-1/2 rounded-full bg-[#F5A623]/10 blur-[100px]" aria-hidden="true" />
      <div className="container relative z-10">
        <div className="grid gap-14 lg:grid-cols-[1fr_.9fr] lg:gap-24">
          <div>
            <span className="section-marker">What happens next</span>
            <h2 className="max-w-2xl text-[#F1EDED]">Help us build a social product worth returning to.</h2>
            <p className="mt-7 max-w-xl text-lg leading-relaxed text-[#F1EDED]/62">The next milestone is not more features. It is evidence: that the right introduction can feel more valuable than an hour of scrolling.</p>
            <a href="mailto:hello@grinsocial.com?subject=GrinSocial%20Beta" className="cta-button mt-9 gap-3">Join the beta conversation <ArrowRight size={18} /></a>
          </div>
          <div className="border-t border-[#F5A623]/30 pt-5">
            <div className="mb-7 flex items-center gap-3 text-[#F5A623]"><Sparkles size={18} /><span className="text-xs uppercase tracking-[.18em]" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>The first validation loop</span></div>
            <ul className="space-y-5">{nextSteps.map((step) => <li key={step} className="flex gap-4"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#F5A623]/10 text-[#F5A623]"><Check size={14} /></span><span className="text-base leading-relaxed text-[#F1EDED]/70">{step}</span></li>)}</ul>
            <div className="mt-10 flex items-center gap-3 border-t border-[#F1EDED]/10 pt-6 text-sm text-[#F1EDED]/45"><Mail size={16} className="text-[#F5A623]" />Prefer a note? hello@grinsocial.com</div>
          </div>
        </div>
      </div>
    </section>
  );
}
