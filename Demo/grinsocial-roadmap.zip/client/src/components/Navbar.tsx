/* Timeless Void: the navbar stays quiet and translucent so the roadmap remains the hero. */
import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';

const links = [
  { label: 'Vision', href: '#vision' },
  { label: 'Roadmap', href: '#roadmap' },
  { label: 'Rules', href: '#rules' },
  { label: 'Safety', href: '#safety' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${scrolled ? 'border-b border-[#F5A623]/15 bg-[#0A0B0F]/85 backdrop-blur-xl' : 'bg-transparent'}`}>
      <div className="container flex h-16 items-center justify-between lg:h-20">
        <a href="#top" className="flex items-center gap-3" aria-label="GrinSocial home">
          <img src="/manus-storage/grinsocial-logo_71205830.png" alt="" className="h-9 w-9 object-contain lg:h-10 lg:w-10" />
          <span className="text-lg font-bold text-[#F1EDED]" style={{ fontFamily: "'Playfair Display', serif" }}>GrinSocial</span>
        </a>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Primary navigation">
          {links.map((link) => (
            <a key={link.href} href={link.href} className="text-sm font-medium text-[#F1EDED]/70 transition-colors hover:text-[#F5A623]" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{link.label}</a>
          ))}
          <a href="#beta" className="cta-button !px-5 !py-2.5 text-sm">Join beta</a>
        </nav>

        <button type="button" onClick={() => setOpen(!open)} className="rounded-lg p-2 text-[#F5A623] hover:bg-[#F5A623]/10 md:hidden" aria-label={open ? 'Close menu' : 'Open menu'}>
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <nav className="border-b border-[#F5A623]/15 bg-[#0A0B0F]/95 px-4 py-5 backdrop-blur-xl md:hidden" aria-label="Mobile navigation">
          <div className="container flex flex-col gap-4">
            {links.map((link) => <a key={link.href} href={link.href} onClick={() => setOpen(false)} className="py-2 text-[#F1EDED]/80 hover:text-[#F5A623]">{link.label}</a>)}
            <a href="#beta" onClick={() => setOpen(false)} className="cta-button text-center text-sm">Join beta</a>
          </div>
        </nav>
      )}
    </header>
  );
}
