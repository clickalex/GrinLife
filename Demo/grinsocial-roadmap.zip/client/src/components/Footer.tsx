/* Timeless Void: the footer is a quiet landing point with the amber mark as the final memory thread. */
import { ArrowUpRight } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-[#F5A623]/15 bg-[#0A0B0F] py-10">
      <div className="container flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
        <div><a href="#top" className="flex items-center gap-3"><img src="/manus-storage/grinsocial-logo_71205830.png" alt="" className="h-8 w-8" /><span className="text-lg font-bold text-[#F1EDED]" style={{ fontFamily: "'Playfair Display', serif" }}>GrinSocial</span></a><p className="mt-3 max-w-sm text-sm leading-relaxed text-[#F1EDED]/42">A feed-free social platform for genuine connection without algorithmic noise.</p></div>
        <div className="flex flex-col items-start gap-4 text-sm text-[#F1EDED]/45 md:items-end"><a href="#top" className="flex items-center gap-2 transition-colors hover:text-[#F5A623]">Back to top <ArrowUpRight size={14} /></a><span>Product roadmap · August 2026</span></div>
      </div>
    </footer>
  );
}
