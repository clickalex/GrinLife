/* Timeless Void: vision cards are compact, tactile proof points against the quiet dark field. */
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { MessageCircle, Sparkles, Users, MapPin } from 'lucide-react';

const points = [
  { icon: MessageCircle, title: 'No-feed model', text: 'No ranking, no infinite scroll, no content treadmill. Connection happens in direct messages and small groups.' },
  { icon: Sparkles, title: 'Preference-driven matching', text: 'Interests, sports, location, and intent shape introductions without the fatigue of swiping or public rejection.' },
  { icon: Users, title: 'Purpose-built groups', text: 'People gather around a reason: a city, a sport, a trip, or a shared plan that makes showing up feel natural.' },
  { icon: MapPin, title: 'Preferences that evolve', text: 'Your settings are living signals. When they change, matches and groups adapt with warning, context, and grace.' },
];

export default function VisionSection() {
  const { ref, inView } = useInView({ threshold: .12, triggerOnce: true });
  return (
    <section id="vision" className="relative overflow-hidden bg-[#0A0B0F] section-py">
      <div className="memory-thread" />
      <div className="container relative z-10">
        <div ref={ref} className="grid gap-14 lg:grid-cols-[.8fr_1.2fr] lg:gap-24">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }} transition={{ duration: .6 }}>
            <span className="section-marker">The premise</span>
            <h2 className="max-w-xl text-[#F1EDED]">The social layer gets lighter when the feed disappears.</h2>
            <p className="mt-7 max-w-lg text-base leading-relaxed text-[#F1EDED]/62 lg:text-lg">GrinSocial is designed around a simple belief: people do not need more content to feel connected. They need a clear reason to say hello, and a safer place to keep the conversation going.</p>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }} transition={{ duration: .65, delay: .1 }} className="grid gap-4 sm:grid-cols-2">
            {points.map(({ icon: Icon, title, text }, index) => (
              <motion.article key={title} initial={{ opacity: 0, y: 16 }} animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }} transition={{ duration: .5, delay: index * .08 }} className="glass-card p-6">
                <div className="mb-6 flex h-11 w-11 items-center justify-center rounded-lg bg-[#F5A623]/10 text-[#F5A623]"><Icon size={21} /></div>
                <h3 className="text-xl text-[#F1EDED]">{title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-[#F1EDED]/56">{text}</p>
              </motion.article>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
