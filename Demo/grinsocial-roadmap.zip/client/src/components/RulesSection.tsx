/* Timeless Void: rules are presented as calm operating principles, not feature clutter. */
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, Clock3, HeartHandshake, ShieldCheck, UsersRound } from 'lucide-react';

const rules = [
  { id: 'preferences', label: 'Preferences', icon: Clock3, title: 'Living settings, never hidden consequences', body: 'People can edit interests, sports, location, journey plans, and connection intent whenever they need to. Before a change is confirmed, GrinSocial previews what will be affected — for example, “You’ll leave 3 groups and lose 5 matches.” High-engagement connections receive a 7-day grace period.' },
  { id: 'matching', label: 'Matching', icon: HeartHandshake, title: 'Curated introductions over infinite choice', body: 'Matches come from overlapping tags, not a swipe or like mechanic. A weekly cap of roughly 5–10 new matches keeps discovery focused, and chat opens only after both people accept.' },
  { id: 'groups', label: 'Groups', icon: UsersRound, title: 'A reason to gather, built into the product', body: 'Creators can define tag-based groups with automatic or request-based joining. Location groups use coarse city data, sport groups follow profile tags, and journey groups archive after the trip ends rather than disappearing.' },
  { id: 'auto-leave', label: 'Auto-leave', icon: ShieldCheck, title: 'Change without the feeling of rejection', body: 'When a preference changes, GrinSocial checks connected groups and matches, notifies the member first, applies the appropriate delay, and uses neutral system language for the people who remain.' },
];

export default function RulesSection() {
  const [active, setActive] = useState('preferences');
  const selected = rules.find((rule) => rule.id === active) ?? rules[0];
  return (
    <section id="rules" className="relative overflow-hidden bg-[#10131A] section-py">
      <div className="container relative z-10">
        <div className="mb-14 max-w-3xl">
          <span className="section-marker">Core product rules</span>
          <h2 className="text-[#F1EDED]">The details are the difference.</h2>
          <p className="mt-6 text-lg leading-relaxed text-[#F1EDED]/62">These rules are the reference point for design, engineering, and QA across every phase — especially where a small interaction can change how safe or welcome a connection feels.</p>
        </div>

        <div className="grid gap-5 lg:grid-cols-[.72fr_1.28fr] lg:gap-10">
          <div className="flex flex-col gap-2">
            {rules.map((rule, index) => {
              const Icon = rule.icon;
              const isActive = active === rule.id;
              return (
                <button key={rule.id} type="button" onClick={() => setActive(rule.id)} className={`group flex items-center justify-between rounded-lg border px-5 py-5 text-left transition-all ${isActive ? 'border-[#F5A623]/55 bg-[#F5A623]/10' : 'border-[#F1EDED]/10 bg-[#0A0B0F]/20 hover:border-[#F5A623]/25'}`}>
                  <span className="flex items-center gap-4"><span className={`flex h-10 w-10 items-center justify-center rounded-lg ${isActive ? 'bg-[#F5A623] text-[#0A0B0F]' : 'bg-[#F1EDED]/5 text-[#F5A623]'}`}><Icon size={19} /></span><span><span className="block text-xs uppercase tracking-[.16em] text-[#F1EDED]/40" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>0{index + 1}</span><span className={`block text-base font-semibold ${isActive ? 'text-[#F5A623]' : 'text-[#F1EDED]/75'}`}>{rule.label}</span></span></span>
                  <ChevronRight size={19} className={`transition-transform ${isActive ? 'translate-x-1 text-[#F5A623]' : 'text-[#F1EDED]/25 group-hover:translate-x-1'}`} />
                </button>
              );
            })}
          </div>

          <div className="relative min-h-[330px] overflow-hidden rounded-xl border border-[#F5A623]/20 bg-[#0A0B0F] p-7 lg:p-10">
            <img src="/manus-storage/grinsocial-matching-visual_aced721e.png" alt="Abstract visual showing preference-driven connections" className="absolute inset-0 h-full w-full object-cover opacity-20" />
            <div className="absolute inset-0 bg-gradient-to-br from-[#0A0B0F]/75 via-[#0A0B0F]/80 to-[#0A0B0F]/55" />
            <div className="relative z-10">
              <AnimatePresence mode="wait">
                <motion.div key={selected.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: .25 }}>
                  <span className="text-xs uppercase tracking-[.18em] text-[#F5A623]" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Rule {rules.findIndex((rule) => rule.id === selected.id) + 1} / 4</span>
                  <h3 className="mt-8 max-w-xl text-3xl leading-tight text-[#F1EDED] lg:text-4xl">{selected.title}</h3>
                  <p className="mt-6 max-w-xl text-base leading-relaxed text-[#F1EDED]/65">{selected.body}</p>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
