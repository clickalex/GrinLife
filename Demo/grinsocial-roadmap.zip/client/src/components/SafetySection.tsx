/* Timeless Void: safety is a warm shield, using the same visual language as connection rather than fear. */
import { motion } from 'framer-motion';
import { AlertTriangle, EyeOff, Flag, TimerReset } from 'lucide-react';

const safeguards = [
  { icon: Flag, title: 'Always available', text: 'Report and block actions stay visible on every chat and every group from day one.' },
  { icon: TimerReset, title: 'Rate-limited by design', text: 'New accounts receive controlled join and match volume to slow spam and bot activity.' },
  { icon: EyeOff, title: 'Coarse location by default', text: 'City-level data powers local discovery. Precise GPS is never required for group matching.' },
];

export default function SafetySection() {
  return (
    <section id="safety" className="relative overflow-hidden bg-[#0A0B0F] section-py">
      <div className="container relative z-10">
        <div className="grid items-center gap-12 lg:grid-cols-[1.08fr_.92fr] lg:gap-20">
          <div>
            <span className="section-marker">Trust & safety</span>
            <h2 className="max-w-2xl text-[#F1EDED]">Make room for people. Keep the edges protected.</h2>
            <p className="mt-7 max-w-xl text-lg leading-relaxed text-[#F1EDED]/62">The roadmap treats trust as a product layer, not a policy page. It is built into the surfaces where people message, join, meet, and change their minds.</p>
            <div className="mt-10 grid gap-4 sm:grid-cols-3">
              {safeguards.map(({ icon: Icon, title, text }) => (
                <article key={title} className="border-t border-[#F5A623]/30 pt-4">
                  <Icon size={19} className="mb-5 text-[#F5A623]" />
                  <h3 className="text-base text-[#F1EDED]">{title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-[#F1EDED]/52">{text}</p>
                </article>
              ))}
            </div>
          </div>
          <motion.div initial={{ opacity: 0, scale: .97 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true, amount: .25 }} transition={{ duration: .7 }} className="relative min-h-[420px] overflow-hidden rounded-2xl border border-[#F5A623]/20">
            <img src="/manus-storage/grinsocial-safety-visual_38a193b9.png" alt="Abstract shield-like forms representing trust and safety" className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A0B0F] via-[#0A0B0F]/35 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-7 lg:p-9">
              <div className="mb-3 flex items-center gap-2 text-[#F5A623]"><AlertTriangle size={17} /><span className="text-xs uppercase tracking-[.16em]" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Open risk to validate</span></div>
              <p className="max-w-md text-sm leading-relaxed text-[#F1EDED]/72">If Phase 2 skews toward in-person meetups, the Phase 3 safety work may need to move earlier. The roadmap leaves room to respond to real behavior.</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
