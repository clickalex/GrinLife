/* Nocturne Constellation: this system map is the signature GrinSocial motif — linked rings, product signals, and human-scale conversation. */
import { motion } from 'framer-motion';
import { ArrowDownRight, Check, CircleDot, MessageCircle, Shield, Users } from 'lucide-react';

const nodes = [
  { label: 'Preferences', sub: 'what matters to you', icon: CircleDot, tone: 'amber' },
  { label: 'Match', sub: 'a reason to say hello', icon: MessageCircle, tone: 'lunar' },
  { label: 'Group', sub: 'a reason to return', icon: Users, tone: 'amber' },
  { label: 'Trust', sub: 'a safer place to stay', icon: Shield, tone: 'lunar' },
];

export default function ConnectionMapSection() {
  return (
    <section className="relative overflow-hidden bg-[#0A0B0F] py-20 lg:py-28">
      <div className="container relative z-10">
        <div className="mb-10 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
          <div className="max-w-2xl"><span className="section-marker">The connection loop</span><h2 className="text-[#F1EDED]">A social product with a visible point of view.</h2></div>
          <p className="max-w-sm text-sm leading-relaxed text-[#F1EDED]/48 lg:text-right">Every product layer answers the same question: what makes a real conversation more likely to happen?</p>
        </div>

        <div className="relative overflow-hidden rounded-2xl border border-[#F5A623]/18 bg-[#10131A] p-6 lg:p-10">
          <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle at 20% 20%, rgba(245,166,35,.14) 0 1px, transparent 1px), radial-gradient(circle at 80% 70%, rgba(86,177,183,.12) 0 1px, transparent 1px)', backgroundSize: '28px 28px, 42px 42px' }} />
          <div className="relative z-10 grid items-center gap-10 lg:grid-cols-[1.15fr_.85fr] lg:gap-16">
            <div className="relative">
              <div className="absolute left-7 top-9 hidden h-[calc(100%-4.5rem)] w-px bg-gradient-to-b from-[#F5A623]/50 via-[#6DB3B5]/35 to-transparent sm:block" />
              <div className="space-y-4">
                {nodes.map(({ label, sub, icon: Icon, tone }, index) => (
                  <motion.div key={label} initial={{ opacity: 0, x: -12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: .3 }} transition={{ duration: .45, delay: index * .08 }} className="relative flex items-center gap-4 rounded-xl border border-[#F1EDED]/8 bg-[#0A0B0F]/55 p-4 sm:ml-2 sm:max-w-lg sm:pl-5">
                    <div className={`relative z-10 flex h-9 w-9 items-center justify-center rounded-full border ${tone === 'amber' ? 'border-[#F5A623]/60 bg-[#F5A623]/10 text-[#F5A623]' : 'border-[#6DB3B5]/55 bg-[#6DB3B5]/10 text-[#8AC7C8]'}`}><Icon size={17} /></div>
                    <div><p className="font-semibold text-[#F1EDED]">{label}</p><p className="text-sm text-[#F1EDED]/45">{sub}</p></div>
                    {index < nodes.length - 1 && <ArrowDownRight size={15} className="absolute -bottom-5 left-6 z-20 text-[#F5A623]/50 sm:left-7" />}
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="relative rounded-xl border border-[#6DB3B5]/25 bg-[#0A0B0F]/70 p-6 lg:p-7">
              <div className="mb-5 flex items-center justify-between"><span className="text-xs uppercase tracking-[.16em] text-[#8AC7C8]" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>A conversation begins</span><span className="h-2 w-2 rounded-full bg-[#F5A623]" /></div>
              <div className="space-y-3 text-sm">
                <div className="max-w-[85%] rounded-2xl rounded-bl-sm bg-[#F1EDED]/8 px-4 py-3 text-[#F1EDED]/68">You both picked weekend hikes + new cities.</div>
                <div className="ml-auto max-w-[82%] rounded-2xl rounded-br-sm bg-[#F5A623] px-4 py-3 text-[#0A0B0F]">I’m planning Porto in October — want to compare notes?</div>
                <div className="flex items-center gap-2 pt-2 text-xs text-[#F1EDED]/38"><Check size={13} className="text-[#6DB3B5]" /> Mutual opt-in · direct message unlocked</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
