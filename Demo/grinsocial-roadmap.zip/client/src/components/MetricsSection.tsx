/* Timeless Void: metrics use restrained numerals and amber highlights to make learning visible without turning the page into a dashboard. */
import { BarChart3, Gauge, Handshake, TrendingUp } from 'lucide-react';

const metrics = [
  { phase: '01 / MVP', icon: Gauge, signal: 'Are people completing the setup and starting a conversation?', items: ['Signup → preference completion', 'First-message rate', 'D1 / D7 retention', 'Match acceptance rate'] },
  { phase: '02 / Groups', icon: Handshake, signal: 'Do groups create a reason to return?', items: ['Groups created per week', 'Group join rate', '30-day group retention', 'Journey-group completion'] },
  { phase: '03 / Safety', icon: BarChart3, signal: 'Can trust scale with activity?', items: ['Report volume', 'Report → resolution time', 'Repeat-offender rate', 'Blocks per 1,000 matches'] },
  { phase: '04 / Growth', icon: TrendingUp, signal: 'Can the product grow without compromising intent?', items: ['Premium conversion', 'Referral coefficient', 'MoM active-user growth', 'Revenue per active user'] },
];

export default function MetricsSection() {
  return (
    <section className="relative overflow-hidden bg-[#10131A] section-py">
      <div className="container relative z-10">
        <div className="mb-14 flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-2xl"><span className="section-marker">Signals, not vanity</span><h2 className="text-[#F1EDED]">Every phase has a question to answer.</h2></div>
          <p className="max-w-sm text-sm leading-relaxed text-[#F1EDED]/52 lg:text-right">The goal is not to move quickly for its own sake. It is to know what is working before adding another layer.</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {metrics.map(({ phase, icon: Icon, signal, items }) => (
            <article key={phase} className="glass-card p-6">
              <div className="mb-8 flex items-center justify-between"><span className="text-xs uppercase tracking-[.17em] text-[#F5A623]" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{phase}</span><Icon size={19} className="text-[#F5A623]" /></div>
              <p className="min-h-[72px] text-base font-semibold leading-relaxed text-[#F1EDED]">{signal}</p>
              <ul className="mt-7 space-y-3 border-t border-[#F1EDED]/10 pt-5">{items.map((item) => <li key={item} className="flex gap-2 text-sm text-[#F1EDED]/55"><span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-[#F5A623]" />{item}</li>)}</ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
