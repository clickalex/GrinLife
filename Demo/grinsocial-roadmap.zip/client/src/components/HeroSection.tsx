/* Timeless Void: the hero is a low-key, image-led opening with one warm signal — the amber promise of intentional connection. */
import { motion } from 'framer-motion';

export default function HeroSection() {
  return (
    <section id="top" className="relative flex min-h-[760px] items-center overflow-hidden pt-20 lg:min-h-screen">
      <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: "url('/manus-storage/grinsocial-hero-bg_467809ec.png')" }} aria-hidden="true">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_72%_34%,rgba(245,166,35,.16),transparent_30%),linear-gradient(90deg,rgba(10,11,15,.93)_0%,rgba(10,11,15,.64)_48%,rgba(10,11,15,.35)_100%)]" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A0B0F]/30 via-transparent to-[#0A0B0F]" />
      </div>

      <div className="container relative z-10 py-24 lg:py-36">
        <div className="max-w-3xl">
          <motion.span initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .55 }} className="section-marker">Product roadmap · August 2026</motion.span>
          <motion.h1 initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .65, delay: .08 }} className="max-w-3xl text-5xl font-bold leading-[1.03] tracking-[-.04em] text-[#F1EDED] sm:text-6xl lg:text-8xl" style={{ fontFamily: "'Playfair Display', serif" }}>
            Skip the feed.<br /><span className="text-[#F5A623]">Connect with intention.</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .65, delay: .16 }} className="mt-8 max-w-2xl text-lg leading-relaxed text-[#F1EDED]/72 lg:text-xl">
            GrinSocial is a feed-free social platform built around direct, SMS-style messaging and small groups — so discovery starts with shared interests, not endless scrolling.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .65, delay: .24 }} className="mt-10 flex flex-col gap-3 sm:flex-row">
            <a href="#beta" className="cta-button">Join the beta</a>
            <a href="#vision" className="inline-flex items-center justify-center rounded-[.55rem] border border-[#F5A623]/65 px-7 py-3.5 font-semibold text-[#F5A623] transition-colors hover:bg-[#F5A623]/10" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>See the thinking</a>
          </motion.div>
        </div>

        <div className="mt-20 flex items-end justify-between border-t border-[#F1EDED]/15 pt-6 lg:mt-28">
          <p className="max-w-xs text-sm leading-relaxed text-[#F1EDED]/48">A calmer social layer for people who value time, trust, and a reason to reach out.</p>
          <div className="hidden items-center gap-3 text-xs uppercase tracking-[.18em] text-[#F5A623]/70 sm:flex" style={{ fontFamily: "'Space Grotesk', sans-serif" }}><span className="h-2 w-2 rounded-full bg-[#F5A623] drift" />Scroll to explore</div>
        </div>
      </div>
    </section>
  );
}
