/* Timeless Void: staggered roadmap markers follow the memory-thread motif and use amber as the phase signal. */
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ArrowUpRight, CheckCircle2 } from 'lucide-react';

const phases = [
  {
    id: '00',
    label: 'Foundation',
    timeline: 'Weeks 1–6',
    goal: 'Lock the product’s operating system before product code begins.',
    detail: 'Finalize the data model, matching logic, safety framework, and legal review of messaging and location handling.',
    success: 'Signed-off spec · Prototype validated on sample data',
  },
  {
    id: '01',
    label: 'MVP Launch',
    timeline: 'Weeks 7–16',
    goal: 'Prove that a feed-free social loop can create momentum.',
    detail: 'Account setup, preference onboarding, SMS-style 1:1 chat, system-driven matching, profile editing, and manual auto-leave logic.',
    success: '500–1,000 beta users · 40% preference completion · 25% first message in 48h',
  },
  {
    id: '02',
    label: 'Groups',
    timeline: 'Weeks 17–26',
    goal: 'Give people a reason to keep showing up together.',
    detail: 'User-created groups, location and sport groups, time-bound journey groups, plus preference-change previews and grace periods.',
    success: '30% of active users join a group · 50% group retention at 30 days',
  },
  {
    id: '03',
    label: 'Trust & Safety',
    timeline: 'Weeks 27–36',
    goal: 'Scale connection without scaling risk.',
    detail: 'Reporting and blocking on every surface, rate limits, moderation dashboard, abuse-pattern detection, coarse location controls, and verified accounts.',
    success: '<24h median report response · <2% of matches result in block/report',
  },
  {
    id: '04',
    label: 'Growth & Monetization',
    timeline: 'Weeks 37–52',
    goal: 'Build a durable business around meaningful connection.',
    detail: 'Premium features, referrals, and partner integrations for travel and event-based journey groups.',
    success: 'Positive premium unit economics · 10%+ month-over-month active-user growth',
  },
];

export default function RoadmapSection() {
  const { ref, inView } = useInView({ threshold: 0.08, triggerOnce: true });

  return (
    <section id="roadmap" className="relative section-py overflow-hidden bg-[#0D0F14]">
      <div className="memory-thread opacity-60" />
      <div className="container relative z-10">
        <div ref={ref} className="max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 18 }}
            transition={{ duration: 0.55 }}
            className="max-w-3xl mb-16"
          >
            <span className="section-marker">The path ahead</span>
            <h2 className="text-[#F1EDED] mb-6">A roadmap that earns its next step.</h2>
            <p className="text-[#F1EDED]/65 text-lg max-w-2xl">
              Each phase is a learning loop, not a vanity milestone. We move forward when the product proves that the previous layer of connection is useful, safe, and worth returning to.
            </p>
          </motion.div>

          <div className="relative">
            <div className="hidden lg:block absolute left-[7.2rem] right-0 top-[2.35rem] h-px bg-gradient-to-r from-[#F5A623]/60 via-[#F5A623]/20 to-transparent" />
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 lg:gap-4">
              {phases.map((phase, index) => (
                <motion.article
                  key={phase.id}
                  initial={{ opacity: 0, y: 24 }}
                  animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 24 }}
                  transition={{ duration: 0.5, delay: index * 0.08 }}
                  className="relative flex flex-col"
                >
                  <div className="flex items-center gap-3 mb-5">
                    <div className="relative z-10 w-12 h-12 rounded-full border border-[#F5A623]/70 bg-[#0D0F14] flex items-center justify-center text-[#F5A623] font-semibold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                      {phase.id}
                    </div>
                    <span className="text-xs uppercase tracking-[0.18em] text-[#F1EDED]/45" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{phase.timeline}</span>
                  </div>
                  <div className="glass-card flex-1 !p-5 lg:!p-6">
                    <h3 className="text-[#F1EDED] text-xl mb-3">{phase.label}</h3>
                    <p className="text-[#F5A623] text-sm font-medium leading-relaxed mb-4">{phase.goal}</p>
                    <p className="text-[#F1EDED]/58 text-sm leading-relaxed mb-6">{phase.detail}</p>
                    <div className="mt-auto pt-4 border-t border-[#F5A623]/15 flex gap-2 items-start">
                      <CheckCircle2 className="w-4 h-4 text-[#F5A623] shrink-0 mt-0.5" />
                      <p className="text-[#F1EDED]/55 text-xs leading-relaxed">{phase.success}</p>
                    </div>
                  </div>
                  {index < phases.length - 1 && <ArrowUpRight className="hidden lg:block absolute -right-3 top-4 w-5 h-5 text-[#F5A623]/60" />}
                </motion.article>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
