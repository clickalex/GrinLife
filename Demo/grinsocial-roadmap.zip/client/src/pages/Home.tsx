/* Timeless Void: the page composes expansive narrative sections with a continuous amber connection thread. */
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import VisionSection from '@/components/VisionSection';
import ConnectionMapSection from '@/components/ConnectionMapSection';
import RoadmapSection from '@/components/RoadmapSection';
import RulesSection from '@/components/RulesSection';
import SafetySection from '@/components/SafetySection';
import MetricsSection from '@/components/MetricsSection';
import BetaSection from '@/components/BetaSection';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <div className="min-h-screen overflow-x-hidden bg-[#0A0B0F] text-[#F1EDED]">
      <Navbar />
      <main>
        <HeroSection />
        <VisionSection />
        <ConnectionMapSection />
        <RoadmapSection />
        <RulesSection />
        <SafetySection />
        <MetricsSection />
        <BetaSection />
      </main>
      <Footer />
    </div>
  );
}
