/**
 * GrinLife Lantern Trail design: a warm, accessible roadmap that explains every phase twice—
 * first in child-friendly language, then in full internal delivery detail.
 */
import { useMemo, useState } from "react";
import {
  Archive,
  ArrowDown,
  ArrowRight,
  BookOpen,
  Brain,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  Compass,
  Globe2,
  Heart,
  HeartHandshake,
  KeyRound,
  LockKeyhole,
  Package,
  Route,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";

const ASSETS = {
  hero: "/manus-storage/grinlife-lantern-trail-hero_0072f464.jpg",
  connect: "/manus-storage/grinlife-connect-garden_277010c1.jpg",
  legacy: "/manus-storage/grinlife-legacy-vault_fd32a0e2.jpg",
  logo: "/manus-storage/grinlife-lantern-logo_8d4d146f.png",
};

type Phase = {
  id: number;
  title: string;
  short: string;
  status: string;
  kidWords: string;
  duration: string;
  build: string[];
  dependsOn: string[];
  proof: string[];
};

type AuditFix = {
  id: string;
  title: string;
  childIssue: string;
  childFix: string;
  parentIssue: string;
  parentFix: string;
  owner: string;
  proof: string;
};

const auditFixes: AuditFix[] = [
  { id: "shared-app", title: "One real GrinLife home", childIssue: "Right now, the three big ideas need one real home to live in.", childFix: "We build one safe app with three doors, instead of gluing three separate houses together.", parentIssue: "The reviewed concepts do not yet show a complete shared authenticated product boundary, account journey, or integrated operating foundation.", parentFix: "Create one canonical modular-monolith application with real routes, APIs, loading/error states, and firm Connect, Chance, Legacy, Identity, Consent, Safety, Asset, AI, Commerce, and Operations boundaries.", owner: "Platform", proof: "A test user can register, sign in, manage settings, and complete monitored app journeys." },
  { id: "privacy", title: "Keep each door private", childIssue: "A friend from one room should not peek into your family memory room.", childFix: "Every door gets its own key. Sharing always needs a clear yes.", parentIssue: "A shared account could accidentally expose Connect profiles to Chance participants or Legacy assets to social contacts.", parentFix: "Use deny-by-default module entitlements, versioned consent, separate discovery indexes, and asset-level permissions. Legacy assets and derived metadata never enter social discovery.", owner: "Platform + Legacy", proof: "Authorization tests prove that social and Chance users cannot read Legacy assets, family roles, or private fields." },
  { id: "safety", title: "Make the help button real", childIssue: "It is not enough to say there is help; someone has to answer when a person needs it.", childFix: "We build a real safety team path with block, report, caring helpers, and records.", parentIssue: "Block, report, rate-limit, verification, and moderation concepts are not enough without operational cases, response standards, and appeal paths.", parentFix: "Create a shared safety service with in-context report/block, case queue, severity, rate limits, moderator actions, evidence rules, appeals, and incident playbooks.", owner: "Trust & Safety", proof: "A report receives a case ID, blocking is immediate, moderator actions are logged, and escalation drills meet the service target." },
  { id: "chance", title: "Make Chance safe and lively", childIssue: "A surprise chat should never feel lonely, stuck, or unsafe.", childFix: "We open Chance slowly with safe waiting rooms, clear rules, a quick exit, and enough people to meet.", parentIssue: "Chance needs safe pool density, honest visibility previews, server-controlled timing, reconnection, and abuse control before broad release.", parentFix: "Launch cohort-based windows with adult eligibility policy, low-density fallback, server-authoritative timers, consent preview, active-session controls, and feature flags.", owner: "Chance + Trust & Safety", proof: "Concurrent, timer, reconnect, low-density, report/block, and consent-withdrawal tests pass before beta expansion." },
  { id: "legacy", title: "Protect precious memories", childIssue: "Photos and family stories need strong locks, and people need to know who has a key.", childFix: "We make a private memory room with clear keys, a history of visits, and a way to take things out or remove them.", parentIssue: "Legacy will hold intimate media, documents, AI-derived content, family sharing, and future inheritance workflows without an implemented governance layer.", parentFix: "Use encrypted object storage, scanning, asset-level access, export/delete, audit events, retention rules, and separate controls for original versus AI-derived data.", owner: "Legacy + Platform", proof: "Users can upload, export, delete, revoke access, and inspect audit events; unauthorized access fails." },
  { id: "ai", title: "Let AI help honestly", childIssue: "A clever helper can make a mistake, so it must show where its ideas came from.", childFix: "Every AI story shows its source memories, lets people edit it, and can be erased if needed.", parentIssue: "Biography, OCR, relationship mapping, and search can be inaccurate, costly, permission-blind, or mistaken for verified history.", parentFix: "Centralize AI orchestration with permission-aware retrieval, source provenance, editable AI-assisted labels, cost caps, retries, deletion propagation, and human review controls.", owner: "AI & Search", proof: "Every output identifies sources, respects permissions, supports edit/delete, exposes processing status, and stays within budget." },
  { id: "family", title: "Never open a family door by accident", childIssue: "Family memories should only open at the right time, after the right grown-ups check carefully.", childFix: "We use a careful checklist with stop buttons, waiting time, and a real person to help when something is confusing.", parentIssue: "Inheritance, trusted contacts, and posthumous access create irreversible privacy, dispute, and legal risks if treated as a simple setting.", parentFix: "Use an explicit state machine with creator, beneficiary, trigger, verification, waiting period, review, cancellation, dispute, and immutable audit states; obtain legal review for jurisdiction-specific claims.", owner: "Legacy + Support", proof: "Revocation, mistaken trigger, compromise, conflict, verification, and escalation cases pass without accidental release." },
  { id: "scope", title: "Do not build every room at once", childIssue: "A giant treehouse is safer when we finish one strong room before starting the next.", childFix: "Every good idea stays on the map, but opens only when the earlier step is ready.", parentIssue: "Connect, Chance, and Legacy each contain enough functionality to become separate products; a broad launch would create disconnected demos and unsafe unfinished workflows.", parentFix: "Maintain a feature registry and release states: planned, internal, beta, limited release, general availability, or paused. Preserve every feature while progressive rollout controls exposure.", owner: "Product + Platform", proof: "Every original feature has a module, owner, permissions, analytics event, dependency, test plan, and current release state." },
  { id: "commerce", title: "Choose keepsakes carefully", childIssue: "A printer should only see the exact pages a family chooses for a special book or box.", childFix: "We make a small approval table before any memory goes to a shop.", parentIssue: "Physical products and provenance introduce payment, tax, fulfillment, refunds, vendor access, and privacy obligations that can distract from the trusted vault.", parentFix: "Release commerce only after approved-asset selection. Use a controlled order workspace, narrow vendor access, auditable database records, and optional provenance that never stores private content on-chain.", owner: "Commerce & Operations", proof: "Orders can be reviewed, paid, fulfilled, cancelled, refunded, and supported without broad vault access." },
  { id: "reliability", title: "Keep the path working", childIssue: "A path is not safe if it disappears when someone comes back to it.", childFix: "We test every door on phones, slow internet, and surprise restarts before inviting more people.", parentIssue: "Earlier Grinrex review found placeholder CTAs, incomplete routes, an intermittent blank-render symptom, and delivery/performance concerns.", parentFix: "Replace placeholders with real routes or labeled waitlists; add smoke tests, error monitoring, immutable asset manifests, slow-network/direct-link testing, security headers, lazy media, and rollback support.", owner: "Platform + Operations", proof: "Clean-load, hard reload, mobile, slow-network, direct-link, and rollback checks pass for every release." },
];

const strictSequence = [
  { step: "0", title: "Map and decide", child: "Pack the map and choose the helpers.", parent: "Inventory features and data; set boundaries, risks, ownership, source of truth, and rollback." },
  { step: "1", title: "Safe base camp", child: "Build locks, lights, and a real help button.", parent: "Ship identity, consent, audit, report/block, flags, monitoring, backups, and recovery." },
  { step: "2", title: "Connect beta", child: "Open the friendly club door a little bit.", parent: "Validate preference matching, messages, moderation, safety, and retention with a controlled cohort." },
  { step: "3", title: "Chance beta", child: "Try short surprise chats with safe rules.", parent: "Validate pools, explicit consent, timed sessions, exits, abuse controls, reconnection, and density." },
  { step: "4", title: "Connect groups", child: "Grow safe clubs and little journeys.", parent: "Add roles, groups, group moderation, preference impacts, and grace periods after Connect is stable." },
  { step: "5", title: "Legacy vault", child: "Build the private memory room.", parent: "Prove encrypted asset storage, organization, search, export, deletion, and asset-level permission controls." },
  { step: "6", title: "AI helper", child: "Let a careful helper organize stories.", parent: "Add provenance-aware, permission-aware, editable AI outputs with deletion and cost controls." },
  { step: "7", title: "Family rules", child: "Share memories only with the right keys.", parent: "Add family roles and high-impact inheritance states only after permissions, support, and legal controls pass." },
  { step: "8", title: "Keepsakes", child: "Make special things from approved memories.", parent: "Add controlled commerce, fulfillment, refunds, and narrow vendor access after the vault is trusted." },
  { step: "9", title: "Grow with care", child: "Invite more people when the house is ready.", parent: "Expand pricing, enterprise, languages, partners, and regions only when operations and safety can sustain them." },
];

type ResidualFix = AuditFix & { priority: "P0" | "P1" };

const residualFixes: ResidualFix[] = [
  { id: "recovery", priority: "P0", title: "Protect accounts during recovery", childIssue: "If someone loses a phone, we must make sure the right person gets their account back.", childFix: "Important changes wait, the old account gets a warning, and a careful helper checks unusual requests.", parentIssue: "Stolen sessions, inbox compromise, SIM swaps, or socially engineered support requests could expose vault, family, or inheritance settings.", parentFix: "Use a recovery state machine with step-up verification, cooldowns for sensitive changes, verified-device notices, recovery history, and manual high-risk review. Recovery cannot immediately unlock inheritance or family controls.", owner: "Identity + Support", proof: "Compromised-session, device-loss, recovery-abuse, impersonation, and cancellation cases pass with high-impact changes paused and notified." },
  { id: "age", priority: "P0", title: "Use the right rules for the right age", childIssue: "Not every room is for every age, even when the story is easy for children to understand.", childFix: "We check which doors are okay for each person before the door opens.", parentIssue: "Chance, messaging, groups, AI voice/face, family sharing, and commerce cannot safely use one undifferentiated audience policy.", parentFix: "Create a module-by-country age matrix. Keep Chance adult-only in the initial beta; separate age assurance from public identity; enforce eligibility, mature-content, messaging, payment, and family-sharing rules.", owner: "Identity + Product", proof: "Policy, UX, support, and enforcement tests show ineligible users cannot enter restricted flows or receive restricted notifications." },
  { id: "deletion", priority: "P0", title: "Make erasing really mean erasing", childIssue: "When a person asks to remove something, we need to know every place it travelled.", childFix: "We keep a careful map so the original, copies, helper notes, and old storage all follow the right removal rule.", parentIssue: "Deletion can conflict with backups, caches, indexes, embeddings, exports, moderation evidence, partner systems, and AI-derived outputs.", parentFix: "Maintain a data-lifecycle registry for every data class and build deletion orchestration with explicit, documented exceptions for permitted safety or legal retention.", owner: "Legacy + Operations", proof: "A deletion trace verifies source, index, embedding, cache, export link, and permitted backup-expiry behavior for vault, conversation, report, and AI story." },
  { id: "consent-drift", priority: "P0", title: "Keep permission promises current", childIssue: "Saying yes to one kind of sharing should not secretly mean yes to a new kind later.", childFix: "Every new kind of sharing asks clearly again, and a person can change their mind.", parentIssue: "New features or flags may silently reuse an older consent or expose data in a new context.", parentFix: "Use a versioned consent ledger with purpose, module, jurisdiction, scope, withdrawal effects, and code-enforced policy checks for routes, jobs, and analytics—not UI-only acknowledgement.", owner: "Consent + Platform", proof: "Automated tests reject data access by any feature route, job, or event without a valid policy decision." },
  { id: "safety-capacity", priority: "P0", title: "Make sure helpers can really help", childIssue: "A help button is only good if a real helper knows what to do next.", childFix: "We start with small groups so the safety team has time to listen, act, and explain.", parentIssue: "Technical report/block flows can exist while triage is understaffed, inconsistent, delayed, or unable to manage appeals and escalation.", parentFix: "Operate safety as a staffed service with severity, triage, response targets, evidence minimization, support language, appeals separation, investigator QA, and incident postmortems.", owner: "Trust & Safety", proof: "Tabletop and live drills show urgent reports are triaged, blocked, escalated, and communicated within the stated target." },
  { id: "chance-abuse", priority: "P0", title: "Stop people from gaming Chance", childIssue: "Someone should not be able to make lots of pretend accounts or keep bothering the same person.", childFix: "We notice unusual patterns, give people breaks, and let careful reviewers help when the computer is unsure.", parentIssue: "Account farming, device rotation, repeated exits, harassment patterns, and scripts can evade simple rate limits and disturb pools.", parentFix: "Add layered defenses: risk signals, device/session integrity, velocity and graph limits, cooldowns, repeat-pair avoidance, encounter controls, server-authoritative state, and human review for high-impact decisions.", owner: "Chance + Safety", proof: "Farmed-account, scripted-join, repeat-harassment, timer-tamper, coordinated-exit, and appeal simulations meet false-positive thresholds." },
  { id: "ingestion", priority: "P0", title: "Check every memory before it enters", childIssue: "A file can look like a photo but hide something yucky or broken inside.", childFix: "New memories wait in a little check-in room before they go into the family memory room.", parentIssue: "Uploads can contain malware, deceptive types, hidden metadata, excessive payloads, sensitive material, or media that triggers unsafe processing.", parentFix: "Quarantine uploads; validate type/size server-side; scan and control metadata; use processing queues and short-lived signed URLs; isolate originals from AI pipelines until scan and permission checks complete.", owner: "Legacy + Platform", proof: "Malicious, malformed, oversized, metadata-heavy, duplicate, and interrupted uploads are rejected or safely isolated with recovery." },
  { id: "keys", priority: "P0", title: "Keep the digital keys healthy", childIssue: "A strong lock still needs a plan for changing keys and fixing a broken key safely.", childFix: "We practise changing keys and helping the right person get back in without opening the door to strangers.", parentIssue: "Encryption without key rotation, revocation, recovery, and incident procedures can leave old keys valid or make a vault unrecoverable.", parentFix: "Define key hierarchy, module boundaries, rotation, revocation, hardware-backed secret storage, recovery escrow rules, and a compromised-key playbook. Operators cannot browse plaintext by default.", owner: "Security + Platform", proof: "A key-rotation and compromised-key drill completes without data loss, unauthorized reads, or unbounded interruption." },
  { id: "ai-change", priority: "P1", title: "Check AI when its brain changes", childIssue: "A helper can act differently after it learns something new, so we check it before using it again.", childFix: "We test the helper, save its recipe, watch its budget, and can go back to the last safe version.", parentIssue: "Provider, model, prompt, retention, or evaluation changes can alter AI accuracy, privacy, cost, and output behavior without a normal product release.", parentFix: "Register models, providers, prompts, retrieval sources, retention settings, and evaluations. Pin releases and require permission, regression, quality, safety, cost, and rollback checks before promotion.", owner: "AI + Operations", proof: "A model/provider change can be traced, evaluated, rolled back, and explained with unchanged permission behavior and bounded cost." },
  { id: "third-party", priority: "P1", title: "Be kind to people inside a memory", childIssue: "A family photo can include someone who did not choose to share it.", childFix: "We give people ways to ask for less sharing, careful review, or a small cover over private parts.", parentIssue: "Uploaders may share group media or documents about non-consenting adults, children, or disputed relationships.", parentFix: "Separate uploader control from person-in-content protections: granular sharing, sensitive labels, redaction, objection/report paths, relationship-role limits, and special policy for minors and living third parties.", owner: "Legacy + Safety", proof: "A contested-content case verifies review, restricted sharing, redaction, appeal, and audit behavior." },
  { id: "fairness", priority: "P1", title: "Make matching feel fair", childIssue: "A helper should not keep showing the same kinds of people or make a person feel left out.", childFix: "We explain the simple rules, let people change preferences, and check if the helper is being fair.", parentIssue: "Matching and optimization can create proxy discrimination, repetitive exposure, unexplained nudging, or retention-first outcomes.", parentFix: "Define allowed/prohibited signals, purpose limits, user controls, outcome monitoring, exposure caps, preference edits, plain explanations, and regular fairness reviews.", owner: "Connect + Product", proof: "Pre-release evaluation documents inputs, outcome slices, repeat-match behavior, user controls, and corrective thresholds." },
  { id: "analytics", priority: "P1", title: "Keep counting private", childIssue: "Counting how a path works should not turn into reading someone’s secret diary.", childFix: "We only count what helps us make things safer, and keep private stories out of the counting box.", parentIssue: "Cross-module event tracking can reconstruct sensitive behavior even when product databases have access controls.", parentFix: "Adopt a privacy-scoped analytics taxonomy: no raw Legacy content, unnecessary text, precise location, or sensitive report detail; enforce roles, aggregation, retention, and schema review.", owner: "Analytics + Privacy", proof: "Catalog review and automated tests reject, redact, or aggregate restricted fields before export." },
  { id: "vendors", priority: "P1", title: "Give helpers only the tiny key they need", childIssue: "A printer, translator, or message helper should never get the key to the whole house.", childFix: "Every helper gets one small key for one job, and we take it back when the job ends.", parentIssue: "Cloud, AI, moderation, messaging, payment, print, translation, and support vendors create overlapping external data-access paths.", parentFix: "Maintain processor register, data-flow map, least-privilege scopes, security reviews, retention terms, kill switches, vendor offboarding, and approved-asset-only production access.", owner: "Operations + Commerce", proof: "Every processor has a purpose, minimum scope, owner, review date, retention setting, and exit procedure." },
  { id: "flags", priority: "P1", title: "Do not let a tiny switch open a big door", childIssue: "A small on/off switch should not accidentally open a room that is still being built.", childFix: "Every switch has an owner, a date to check again, and the same safety locks as the real door.", parentIssue: "Feature flags can expose unfinished routes, jobs, notifications, or cohorts and must never act as authorization or consent.", parentFix: "Classify flags by risk; require owner, expiry, target cohort, consent dependency, rollback behavior, and monitoring; test against bypass of age, permission, consent, or evidence gates.", owner: "Platform + Operations", proof: "Cohort-change tests prove flags cannot bypass permissions, consent, age policy, or release evidence." },
  { id: "migration", priority: "P1", title: "Sort mixed-up accounts carefully", childIssue: "Two people can share a phone or two old lists can have the same name, so we must not mix them up.", childFix: "We show a preview, keep a note of where things came from, and ask a person for help when it is confusing.", parentIssue: "Duplicate accounts, shared devices, waitlist identities, conflicting contact records, imports, and archives can create ambiguous or contested ownership.", parentFix: "Define linking, merge, separation, import, and dispute procedures; preserve source provenance; offer preview/undo where safe; require manual review for contested merges.", owner: "Identity + Support", proof: "Duplicate, shared-device, contested-archive, wrong-contact, and reverse-merge cases complete with clear audit trails." },
  { id: "inclusive", priority: "P1", title: "Make every trail easier to use", childIssue: "People need different ways to read, listen, move, wait, and understand the same path.", childFix: "We build keyboard help, captions, slow-internet modes, easy words, and room for many languages from the start.", parentIssue: "Timed encounters, permissions, AI narratives, and inheritance states can exclude people using assistive technology, low bandwidth, or other languages.", parentFix: "Set accessibility/localization release criteria for timing controls, keyboard and screen-reader use, captions/transcripts, simple language, translated expansion, right-to-left readiness, and low-bandwidth behavior.", owner: "Product + Design", proof: "Assistive-tech, keyboard-only, reduced-motion, slow-network, translation-expansion, and timing tests pass for each beta surface." },
  { id: "release", priority: "P1", title: "Give someone power to say ‘not yet’", childIssue: "When a room is not safe, someone needs to be allowed to say ‘wait’ even if everyone is excited.", childFix: "A small grown-up team checks the proof and can pause, fix, or close a door kindly.", parentIssue: "Schedule or commercial pressure can override safety evidence if no one owns a clear no-go decision, risk acceptance, or rollback authority.", parentFix: "Create a release council with Product, Safety, Privacy, Security, and Operations sign-off; define no-go conditions, risk acceptance expiry, rollback authority, and communication templates.", owner: "Release Council", proof: "A simulated no-go and rollback proves the release can pause or revert without ambiguity over decision rights." },
];

const proofDashboard = [
  { title: "Permissions", child: "Only the right key opens the right room.", parent: "Every user, service, job, and analytics event accesses only authorized data." },
  { title: "Account safety", child: "Getting a lost account back needs careful checks.", parent: "High-impact recovery and family changes require step-up verification, cooldowns, alerts, and review." },
  { title: "Human safety", child: "A real helper knows what to do after a report.", parent: "Social beta requires staffed triage, escalation, appeal, and clear user communication." },
  { title: "Data life", child: "We know where information goes and how it leaves.", parent: "Sensitive features require a tested collection-to-deletion-and-backup lifecycle trace." },
  { title: "AI honesty", child: "A helper shows where its ideas came from.", parent: "AI requires source provenance, permission checks, cost bounds, evaluation, and rollback." },
  { title: "Reliability", child: "The path still works on a slow or bumpy trip.", parent: "Cohort expansion requires failure-injection, direct-link, restart, slow-network, and recovery evidence." },
  { title: "Inclusion", child: "Everyone gets a way to use the trail.", parent: "Accessibility and localization blockers stop the affected release." },
  { title: "Decision rights", child: "Someone can always say ‘not yet’.", parent: "Recorded cross-functional sign-off, expiry, and rollback authority are mandatory." },
];

const correctedSequence = [
  { step: "1", title: "Map and decide", child: "Draw the map, name the helpers, and list every door.", parent: "Inventory features, data, vendors, risks, source systems, ownership, and decision rights." },
  { step: "2", title: "Secure identity and recovery", child: "Build the right keys and a careful lost-key plan.", parent: "Deliver authentication, eligibility, recovery state, compromise response, consent ledger, and policy enforcement." },
  { step: "3", title: "Operate safety and data care", child: "Train the helpers and practise keeping secrets safe.", parent: "Staff triage, test deletion/backups, restrict analytics, and establish key and incident management." },
  { step: "4", title: "Run Connect closed beta", child: "Open one friendly club door for a small group.", parent: "Validate introductions, messages, leave/block/report, moderation, accessibility, and retention." },
  { step: "5", title: "Run Chance controlled beta", child: "Try tiny surprise chats with very careful rules.", parent: "Validate pool eligibility, consent, timers, exits, reconnection, adversarial abuse defenses, and density." },
  { step: "6", title: "Expand Connect carefully", child: "Grow clubs only when the helpers are ready.", parent: "Add groups and journeys after recommendation, moderation, and group-safety evidence is sufficient." },
  { step: "7", title: "Open the Legacy vault", child: "Build the private memory room and check every new memory.", parent: "Prove secure ingestion, encryption, permissions, export/deletion, key rotation, and recovery." },
  { step: "8", title: "Add AI assistance", child: "Invite the story helper only after it shows its homework.", parent: "Add traceable, editable, permission-aware AI under model/provider/prompt change management." },
  { step: "9", title: "Enable family rules", child: "Share family keys slowly and carefully.", parent: "Add collaboration and inheritance states after dispute, third-party rights, jurisdiction, and recovery testing." },
  { step: "10", title: "Add keepsakes and grow", child: "Make special things and invite more people when the house is ready.", parent: "Add commerce, provenance, pricing, enterprise, language, and regional scale only with vendor and operational readiness." },
];

const phases: Phase[] = [
  {
    id: 0,
    title: "Get our map ready",
    short: "Choose the safe path before we start building.",
    status: "Plan",
    duration: "2–4 weeks",
    kidWords: "Before a big trip, we pack a map, choose who will help, and agree on the safest route. Phase 0 does that for GrinLife.",
    build: [
      "Give the combined project one name: GrinLife, with three experiences—Connect, Chance, and Legacy.",
      "Create a master feature registry so every useful idea from GrinSocial, GrinLuck, and Grinrex Legacy has a future home.",
      "Agree on the core data model, privacy rules, risks, decision log, release states, and ownership before new features are built.",
      "Choose source-of-truth repositories, data sources, URL strategy, and a clear rollback direction.",
    ],
    dependsOn: ["A confirmed list of all existing features and assets.", "Named owners for product, platform, safety, Legacy, AI, and operations."],
    proof: ["Feature registry approved.", "Architecture and boundaries accepted.", "First-release scope, navigation, and rollback direction documented."],
  },
  {
    id: 1,
    title: "Build the safe base camp",
    short: "Make one strong foundation that every future room can share.",
    status: "Foundation",
    duration: "6–8 weeks",
    kidWords: "A treehouse needs sturdy steps, locks, lights, and a way to ask for help before friends come over. This phase builds those important pieces.",
    build: [
      "Create one account system with sign-in, profile, session, recovery, age checks, privacy choices, and account deletion.",
      "Build a safety center with report, block, moderation queue, appeals, rate limits, notifications, and audit records.",
      "Set up database, encrypted file storage, search foundations, background jobs, feature flags, analytics events, monitoring, staging, backups, and restore drills.",
      "Repair deployment basics: real early-access, demo, contact, and policy pages; no placeholder links; clean-load and rollback testing.",
    ],
    dependsOn: ["Phase 0 architecture and ownership decisions.", "Security and operations review of shared services."],
    proof: ["Account, privacy, block/report, export/delete, and notification paths work.", "Backups and restore work in a drill.", "Staging smoke tests and deployment rollback are documented."],
  },
  {
    id: 2,
    title: "Open the Connect door",
    short: "Help people find thoughtful, safe new connections.",
    status: "Closed beta",
    duration: "8–12 weeks",
    kidWords: "This is like a friendly club where people tell us what they enjoy, then choose who they would like to say hello to. Everyone can say no or leave.",
    build: [
      "Build onboarding for interests, broad location, travel, journeys, and connection intent—plus profiles and visibility controls.",
      "Create eligibility rules, explainable matching, discovery, acceptance, direct messaging, and reconnect handling.",
      "Reuse the safety center for report, block, risk flags, moderation escalation, notification, and account controls.",
      "Add product and safety events so the team can learn whether the loop is useful and safe.",
    ],
    dependsOn: ["Phase 1 identity, privacy, safety, messaging, and analytics.", "A small, invited beta group and clear moderation coverage."],
    proof: ["Concurrent matching and reconnect behavior tested.", "Coarse-location privacy and rate limits verified.", "User feedback, product, and safety review held before expansion."],
  },
  {
    id: 3,
    title: "Try a little happy chance",
    short: "Create short, opt-in encounters that stay safe from start to finish.",
    status: "Closed beta",
    duration: "8–12 weeks",
    kidWords: "Sometimes meeting someone by chance is fun. Here, both people have to say yes, the chat has a gentle timer, and either person can stop at any time.",
    build: [
      "Build an eligible pool, clear entry consent, visibility explanation, density controls, and the randomized Roll experience.",
      "Create a shared Spark prompt, mutual opt-in, short private Talk, independent Choose, continuation or closure, and reconnection only when wanted.",
      "Use a server-authoritative timer, ephemeral sessions, fast exit, timeout, disconnect recovery, block/report, and abuse review.",
      "Keep later GrinLuck ideas—Second Wind, Shared Orbits, Memory Capsules, Bottle messages, translation, Vibe Seeds, Lucky Hours, and seasonal rituals—in the registry for future phases.",
    ],
    dependsOn: ["Phase 1 real-time session infrastructure and safety services.", "Phase 2 lessons about consent, moderation, notifications, and beta operations."],
    proof: ["Timer manipulation, consent withdrawal, capacity, abuse, and disconnect tests pass.", "Every participant can leave quickly and report safely.", "A controlled safety review approves any larger beta."],
  },
  {
    id: 4,
    title: "Grow the Connect garden",
    short: "Let people make groups and journeys, with kind rules and clear exits.",
    status: "Public beta",
    duration: "8–12 weeks",
    kidWords: "After people make a friend, they may want to join a little club or take a short adventure together. This phase helps that happen with grown-up safety helpers nearby.",
    build: [
      "Add user, city, sports, travel, and journey groups with roles, membership, messages, reports, and notifications.",
      "Create time-bound journeys, temporary membership, post-journey outcomes, auto-leave, and safe leaving.",
      "Allow preference changes with a preview, automatic summary, user confirmation, and a seven-day grace period.",
      "Prepare referrals, partner-ready hooks, and retention experiments without adding pay-to-expose incentives.",
    ],
    dependsOn: ["Stable Connect matching and moderation.", "Lifecycle, notification, and audit services from the shared platform."],
    proof: ["Group moderation and role changes are auditable.", "Journey exits and preference updates are clear to users.", "Retention and safety indicators are reviewed together."],
  },
  {
    id: 5,
    title: "Build the Legacy memory room",
    short: "Give each family a private, organized place for precious memories.",
    status: "Private alpha",
    duration: "10–16 weeks",
    kidWords: "This is a careful memory room where photos, stories, and important papers can be kept safe. Only the right people get a key.",
    build: [
      "Create encrypted uploads for photos, documents, audio, and video with validation, resumable ingestion, and background processing.",
      "Add collections, tags, metadata, timelines, duplicate detection, filters, metadata search, and storage status.",
      "Give people true control: view, download, export, delete, retry, storage usage, expiring share links, revocation, and access logs.",
      "Keep Legacy private by default; never send vault assets into discovery or social matching.",
    ],
    dependsOn: ["Encrypted storage, jobs, search base, privacy center, export/delete, and backup/restore evidence from Phase 1."],
    proof: ["Private-by-default access is proven.", "Failure recovery, backups, restore drills, and deletion are verified.", "Share links expire and access changes are recorded."],
  },
  {
    id: 6,
    title: "Add a careful helper for memories",
    short: "Use AI to organize and tell stories, but always show where ideas came from.",
    status: "Private beta",
    duration: "8–14 weeks",
    kidWords: "A helper can sort photos and help write a family story, but it must show which memories it used. People are always in charge of the final story.",
    build: [
      "Add auto-tagging, OCR, document extraction, transcription, timeline suggestions, relationship suggestions, and semantic search.",
      "Create Biography Builder, narrative drafts, editing tools, source-memory display, version history, and relevance feedback.",
      "Use explicit consent, generated-content labels, asynchronous jobs, retry/delete, cost caps, and a documented model-use policy.",
      "Keep facial recognition and relationship mapping as advanced opt-in capabilities only, with deletion controls.",
    ],
    dependsOn: ["Phase 5 vault controls, permissions, and source-asset tracking.", "AI governance, jobs, cost controls, and review procedures."],
    proof: ["Generated content has clear labels and source traces.", "Consent, deletion, and derived-data cleanup work.", "Model cost and failure behavior are monitored."],
  },
  {
    id: 7,
    title: "Invite trusted family members",
    short: "Let families share the right memories with the right people at the right time.",
    status: "Controlled beta",
    duration: "10–16 weeks",
    kidWords: "Families can make a shared memory shelf together. They choose who can look, add something, or help later—nothing opens by accident.",
    build: [
      "Add invitations, family roles, shared collections, comments, collaborative timelines, and a family tree.",
      "Build trusted contacts, beneficiary rules, digital-will workflow, scheduled Time Capsule release, and posthumous access workflows.",
      "Create verification, revocation, cancellation, dispute handling, support, and auditable access for every sensitive action.",
      "Keep the inheritance state machine explicit so no person receives access without verified steps.",
    ],
    dependsOn: ["Phase 5 private vault and Phase 6 permission and provenance controls.", "Legal, privacy, support, and dispute procedures."],
    proof: ["Access is auditable and reversible before release.", "Verification and cancellation paths are tested.", "Dispute workflow and support handoff are ready."],
  },
  {
    id: 8,
    title: "Turn approved memories into keepsakes",
    short: "Make physical books and memory boxes only after people say exactly what may be used.",
    status: "Limited commercial beta",
    duration: "10–18 weeks",
    kidWords: "A family might choose to make a special book or memory box. The printer only receives the pages the family carefully approves.",
    build: [
      "Offer archival books, engraved drives, memory capsules, keepsake boxes, configuration, pricing, cart, payment, tax, proof approval, and production lock.",
      "Add fulfilment, refunds, customer support, asset hashes, and provenance records.",
      "Create vendor boundaries so fulfillment partners receive only approved production assets—never an uncontrolled full-vault view.",
      "Create a simple approval trail from selected memory to final physical product.",
    ],
    dependsOn: ["Vault sharing controls, commerce stack, policies, support, and vendor agreements."],
    proof: ["Proof approval and production lock are demonstrated.", "Refund, cancellation, and support paths work.", "Vendor data access is narrow and logged."],
  },
  {
    id: 9,
    title: "Carefully welcome more people",
    short: "Grow GrinLife only when support, safety, and privacy can grow too.",
    status: "General availability expansion",
    duration: "Ongoing",
    kidWords: "When the house is strong and the helpers are ready, more people can visit. We still keep the same kind rules and safe doors.",
    build: [
      "Add premium Connect, Chance, storage, AI, and family plans; referrals and partnerships; cancellation and refund controls.",
      "Build enterprise accounts, an admin console, support tooling, compliance reporting, multilingual UX, regional policy, payments, and reliability work.",
      "Protect against harmful incentives such as pay-to-expose; keep enterprise accounts isolated and auditable.",
      "Continue global capacity, incident learning, safety review, and privacy controls as the service expands.",
    ],
    dependsOn: ["Evidence from every preceding module and mature operations.", "Regional compliance, support coverage, reliability, and commercial safeguards."],
    proof: ["Monetization is fair and reversible.", "Enterprise and regional controls pass review.", "Reliability, support, and safety operations can handle growth."],
  },
];

type ProofGate = {
  id: "safety" | "security" | "ai-family" | "commerce" | "growth" | "learning";
  title: string;
  child: string;
  parent: string;
  phaseIds: number[];
  icon: React.ReactNode;
};

const proofGates: ProofGate[] = [
  { id: "safety", title: "Safety & privacy", child: "People can choose, leave, get help, and keep private things private.", parent: "Report/block, consent, visibility, deletion, retention, access records, appeals, and incident response must work—not just be written down.", phaseIds: [0, 1, 2, 3, 4, 5, 6, 7, 9], icon: <ShieldCheck /> },
  { id: "security", title: "Security & reliability", child: "The locks work, the path works on a bumpy day, and we know how to fix it.", parent: "Permissions, encryption, secret handling, dependency checks, backups, restore drills, smoke tests, slow-network tests, and rollback plans are required.", phaseIds: [0, 1, 2, 3, 5, 6, 7, 8, 9], icon: <LockKeyhole /> },
  { id: "ai-family", title: "AI & family care", child: "Story helpers show their homework, and family keys stay in the right hands.", parent: "AI needs sources, labels, consent, deletion, and cost controls. Family and inheritance need verified roles, revocation, cancellation, and dispute paths.", phaseIds: [0, 5, 6, 7, 9], icon: <Brain /> },
  { id: "commerce", title: "Keepsake care", child: "A shop only gets the exact memory pages a family says are okay to use.", parent: "Physical keepsakes need approval trails, narrow vendor access, payment, cancellation, refund, fulfilment, support, and provenance records.", phaseIds: [8, 9], icon: <Package /> },
  { id: "growth", title: "Growth readiness", child: "We invite more people only when there are enough kind helpers and sturdy paths.", parent: "More users only arrive when capacity, moderation, support, regional policy, reliability, and fair pricing can grow at the same time.", phaseIds: [4, 9], icon: <Globe2 /> },
  { id: "learning", title: "Learning together", child: "We stop, listen, and learn before turning on the next lantern.", parent: "The team reviews real product, safety, quality, and error signals together. If the evidence says “not ready,” the next lantern waits.", phaseIds: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], icon: <BookOpen /> },
];

const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

function DoorCard({ title, description, icon, className }: { title: string; description: string; icon: React.ReactNode; className: string }) {
  return (
    <article className={`gl-door ${className}`}>
      <div className="gl-door-icon">{icon}</div>
      <h3>{title}</h3>
      <p>{description}</p>
    </article>
  );
}

function moduleForPhase(id: number) {
  if ([2, 4].includes(id)) return { label: "CONNECT DOOR", type: "connect" };
  if (id === 3) return { label: "CHANCE DOOR", type: "chance" };
  if ([5, 6, 7, 8].includes(id)) return { label: "LEGACY DOOR", type: "legacy" };
  if (id === 9) return { label: "ALL THREE DOORS", type: "all" };
  return { label: "BASE CAMP", type: "base" };
}

function Home() {
  const [activePhaseId, setActivePhaseId] = useState(0);
  const [audienceView, setAudienceView] = useState<"child" | "parent">(() => new URLSearchParams(window.location.search).get("view") === "parent" ? "parent" : "child");
  const [exploredPhases, setExploredPhases] = useState<number[]>(() => {
    try {
      const saved = window.localStorage.getItem("grinlife-explored-phases");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [reviewedProofLinks, setReviewedProofLinks] = useState<string[]>(() => {
    try {
      const saved = window.localStorage.getItem("grinlife-reviewed-proof-links");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [highlightedGateId, setHighlightedGateId] = useState<ProofGate["id"] | null>(null);
  const activePhase = useMemo(() => phases.find((phase) => phase.id === activePhaseId) ?? phases[0], [activePhaseId]);
  const activeModule = useMemo(() => moduleForPhase(activePhaseId), [activePhaseId]);
  const activePhaseIndex = useMemo(() => phases.findIndex((phase) => phase.id === activePhaseId), [activePhaseId]);
  const activeProofGates = useMemo(() => proofGates.filter((gate) => gate.phaseIds.includes(activePhaseId)), [activePhaseId]);
  const reviewedActiveProofCount = activeProofGates.filter((gate) => reviewedProofLinks.includes(`${activePhaseId}:${gate.id}`)).length;
  const isChildView = audienceView === "child";
  const isExplored = exploredPhases.includes(activePhaseId);

  const choosePhase = (id: number) => {
    setActivePhaseId(id);
    setHighlightedGateId(null);
    window.setTimeout(() => scrollTo("phase-detail"), 60);
  };

  const movePhase = (direction: -1 | 1) => {
    const next = phases[activePhaseIndex + direction];
    if (next) choosePhase(next.id);
  };

  const toggleExplored = () => {
    setExploredPhases((current) => {
      const next = current.includes(activePhaseId) ? current.filter((id) => id !== activePhaseId) : [...current, activePhaseId];
      try { window.localStorage.setItem("grinlife-explored-phases", JSON.stringify(next)); } catch { /* local progress is optional */ }
      return next;
    });
  };

  const openProofGate = (gateId: ProofGate["id"]) => {
    const reviewKey = `${activePhaseId}:${gateId}`;
    setHighlightedGateId(gateId);
    setReviewedProofLinks((current) => {
      const next = current.includes(reviewKey) ? current : [...current, reviewKey];
      try { window.localStorage.setItem("grinlife-reviewed-proof-links", JSON.stringify(next)); } catch { /* local review tracking is optional */ }
      return next;
    });
    window.setTimeout(() => {
      const target = document.getElementById(`proof-gate-${gateId}`);
      target?.scrollIntoView({ behavior: "smooth", block: "center" });
      target?.focus({ preventScroll: true });
    }, 60);
  };

  const chooseAudience = (view: "child" | "parent") => {
    setAudienceView(view);
    const url = new URL(window.location.href);
    if (view === "parent") url.searchParams.set("view", "parent");
    else url.searchParams.delete("view");
    window.history.replaceState({}, "", url);
  };

  return (
    <div className={`gl-app ${isChildView ? "child-mode" : "parent-mode"}`}>
      <a className="gl-skip" href="#main-content">Skip to the roadmap</a>
      <header className="gl-nav">
        <div className="container gl-nav-inner">
          <a className="gl-brand" href="#top" aria-label="GrinLife home">
            <img className="gl-logo" src={ASSETS.logo} alt="GrinLife lantern mark" />
            <span className="gl-brand-word">GrinLife</span>
          </a>
          <nav className="gl-nav-links" aria-label="Roadmap sections">
            <a href="#story">Our story</a>
            <a href="#trail">The phases</a>
            <a href="#audit">What we fix</a>
            <a href="#second-audit-title">Extra checks</a>
            <a href="#safety">Safety promises</a>
            <a href="#first-90">First 90 days</a>
            <a href="#words">Word helper</a>
          </nav>
          <div className="gl-audience-toggle" role="group" aria-label="Choose how much roadmap detail to show">
            <span className="gl-audience-label">View</span>
            <button className={isChildView ? "active" : ""} onClick={() => chooseAudience("child")} aria-pressed={isChildView}>Child</button>
            <button className={!isChildView ? "active" : ""} onClick={() => chooseAudience("parent")} aria-pressed={!isChildView}>Parent</button>
          </div>
          <button className="gl-nav-cta" onClick={() => scrollTo("trail")}>Start the tour</button>
        </div>
      </header>

      <main id="main-content">
        <section className="gl-hero" id="top" aria-labelledby="hero-title">
          <img className="gl-hero-art" src={ASSETS.hero} alt="A lantern-lit path through a warm storybook landscape" />
          <div className="gl-hero-overlay" />
          <div className="container gl-hero-inner">
            <div className="gl-hero-copy">
              <div className="gl-eyebrow"><span className="gl-lantern-dot" /> The GrinLife Lantern Trail</div>
              <h1 id="hero-title">A big dream, built <em>one safe step</em> at a time.</h1>
              <p>{isChildView ? "GrinLife brings friendship, happy chance, and family memories together. Pick a lantern to see what we will make next and why it matters." : "GrinLife brings friendship, joyful chance, and family memories together. This guide explains every step in plain language—so children, families, and the internal team can follow the same path."}</p>
              <div className="gl-hero-actions">
                <button className="gl-button primary" onClick={() => scrollTo("trail")}>Follow the 10 steps <ArrowDown size={18} /></button>
                <a className="gl-button ghost" href="#story">See the three doors <ArrowRight size={18} /></a>
              </div>
            </div>
            <aside className="gl-hero-note" aria-label="How to use this guide">
              <strong>{isChildView ? "Child view: follow the lanterns" : "Parent view: see the full plan"}</strong>
              <p>{isChildView ? "Each lantern explains one big goal, why it helps, and what must happen before we move on." : "Every phase includes the build list, dependencies, and readiness proof for families and the internal team."}</p>
            </aside>
          </div>
        </section>

        <section className="gl-section warm" id="story" aria-labelledby="story-title">
          <div className="container gl-intro-grid">
            <div>
              <div className="gl-path-stop"><span>01</span><i /> Our first stop: the three doors</div>
              <div className="gl-kicker">One home · three doors</div>
              <h2 className="gl-intro-title" id="story-title">GrinLife is one kind, careful home with three special rooms.</h2>
              <div className="gl-kid-ribbon"><CircleHelp size={16} /> In kid words: one house, three doors, lots of good rules.</div>
              <p className="gl-intro-copy">We do not want three separate products that forget how to talk to each other. GrinLife shares one safe foundation—accounts, privacy controls, help buttons, notifications, and careful records—while each door keeps its own purpose and boundaries.</p>
              <div className="gl-three-doors">
                <DoorCard className="door-connect" icon={<HeartHandshake size={19} />} title="Connect" description="Thoughtful matching, messaging, groups, and journeys." />
                <DoorCard className="door-chance" icon={<Sparkles size={19} />} title="Chance" description="Short, opt-in encounters with kind safety rules." />
                <DoorCard className="door-legacy" icon={<Archive size={19} />} title="Legacy" description="Private memories, family stories, and keepsakes." />
              </div>
            </div>
            <figure className="gl-side-note">
              <img src={ASSETS.connect} alt="People planting seedlings together in a community garden" />
              <figcaption>Connect starts with a simple promise: people should always understand who can see them, why, and how to leave.</figcaption>
            </figure>
          </div>
        </section>

        <section className="gl-section mist" aria-labelledby="foundation-title">
          <div className="container">
            <div className="gl-section-head">
              <div className="gl-path-stop"><span>02</span><i /> Base camp: build the safe path</div>
              <div className="gl-kicker">The base camp</div>
              <h2 id="foundation-title">Before any new room opens, the base camp must be strong.</h2>
              <p className="gl-section-intro">Every later feature uses the same foundation. Building it once makes GrinLife clearer for families and safer for everyone.</p>
            </div>
            <div className="gl-foundation">
              <div className="gl-foundation-label">
                <span>Shared by every door</span>
                <h3>One safe foundation</h3>
                <p>These are the things we build before asking people to match, meet, upload memories, or share with family.</p>
              </div>
              <div className="gl-foundation-grid gl-field-notes">
                <article className="gl-foundation-card"><KeyRound size={23} /><h3>One account</h3><p>Sign-in, recovery, age checks, profile, privacy choices, and a real delete-account path.</p></article>
                <article className="gl-foundation-card"><ShieldCheck size={23} /><h3>One safety center</h3><p>Report, block, moderation, appeals, rate limits, and a way to ask for help.</p></article>
                <article className="gl-foundation-card"><LockKeyhole size={23} /><h3>One privacy promise</h3><p>Permissions, visibility controls, exports, deletion, consent, and an audit trail.</p></article>
                <article className="gl-foundation-card"><Route size={23} /><h3>One delivery path</h3><p>Testing, staging, backups, restore drills, monitoring, and a way to roll back safely.</p></article>
                <article className="gl-foundation-card"><BookOpen size={23} /><h3>One learning notebook</h3><p>Useful product events, error monitoring, and safety review—not hidden guesses.</p></article>
                <article className="gl-foundation-card"><Users size={23} /><h3>One helping team</h3><p>Clear ownership for Platform, Connect, Chance, Legacy, Safety, AI, and Operations.</p></article>
              </div>
            </div>
          </div>
        </section>

        <section className="gl-section warm" id="audit" aria-labelledby="audit-title">
          <div className="container">
            <div className="gl-section-head">
              <div className="gl-path-stop"><span>03</span><i /> A careful pause: fix the big things first</div>
              <div className="gl-kicker">The product repair map</div>
              <h2 id="audit-title">Every big dream has a few things to fix before it is ready to share.</h2>
              <div className="gl-kid-ribbon"><ShieldCheck size={16} /> We keep every good idea. We simply build the safety rails first.</div>
              <p className="gl-section-intro">{isChildView ? "Here are the big problems we must solve and the kind ways we solve them. None of the three doors disappear—we just open each door at the right time." : "This is the GrinLife product risk register. Each gap has a feature-preserving solution, an accountable owner, and release evidence that must exist before the next step."}</p>
            </div>

            {isChildView ? (
              <div className="gl-audit-child-grid">
                {auditFixes.map((fix, index) => (
                  <article className="gl-audit-child-card" key={fix.id}>
                    <span className="gl-audit-number">{String(index + 1).padStart(2, "0")}</span>
                    <h3>{fix.title}</h3>
                    <p><strong>What needs fixing:</strong> {fix.childIssue}</p>
                    <p className="gl-audit-solution"><strong>How we help:</strong> {fix.childFix}</p>
                  </article>
                ))}
              </div>
            ) : (
              <div className="gl-audit-parent-wrap">
                <div className="gl-audit-parent-note"><strong>Parent view: no hidden shortcuts.</strong><span>A phase can move forward only after its proof gate is met. This is how GrinLife preserves all original features without releasing unfinished or unsafe workflows.</span></div>
                <div className="gl-audit-table-wrap">
                  <table className="gl-audit-table">
                    <thead><tr><th>Gap to fix</th><th>Feature-preserving solution</th><th>Owner</th><th>Proof before release</th></tr></thead>
                    <tbody>{auditFixes.map((fix) => <tr key={fix.id}><th scope="row" data-label="Gap to fix"><strong>{fix.title}</strong><span>{fix.parentIssue}</span></th><td data-label="Feature-preserving solution">{fix.parentFix}</td><td data-label="Owner"><span className="gl-owner-stamp">{fix.owner}</span></td><td data-label="Proof before release">{fix.proof}</td></tr>)}</tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="gl-sequence-box" aria-labelledby="sequence-title">
              <div className="gl-sequence-head"><div><span className="gl-sequence-kicker">First audit delivery path</span><h3 id="sequence-title">No skipping lanterns.</h3></div><p>{isChildView ? "This was our first careful path. The stronger safety check below adds even more locks before each room opens." : "This is the first release-control path. The second-pass version below strengthens it with explicit recovery, lifecycle, safety-capacity, and governance gates."}</p></div>
              <ol className="gl-sequence-list">{strictSequence.map((item) => <li key={item.step}><span>{item.step}</span><div><strong>{item.title}</strong><p>{isChildView ? item.child : item.parent}</p></div></li>)}</ol>
            </div>

            <div className="gl-second-audit" aria-labelledby="second-audit-title">
              <div className="gl-second-audit-head"><div><span className="gl-kicker">Second safety check</span><h3 id="second-audit-title">Before a new door opens, we look for the hidden bumps in the path.</h3></div><p>{isChildView ? "This extra check asks, “What could go wrong when real people, lost phones, private memories, and busy helpers are involved?” Then we add another safety rail." : "This second-pass register tests the plan against account compromise, age eligibility, lifecycle drift, operational capacity, adversarial abuse, model/vendor changes, third-party rights, and release pressure."}</p></div>
              {isChildView ? (
                <div className="gl-residual-child-grid">{residualFixes.map((fix, index) => <article className="gl-residual-child-card" key={fix.id}><span className={`gl-priority-dot ${fix.priority.toLowerCase()}`}>{fix.priority}</span><span className="gl-residual-number">{String(index + 1).padStart(2, "0")}</span><h4>{fix.title}</h4><p><strong>The hidden bump:</strong> {fix.childIssue}</p><p className="gl-residual-fix"><strong>Our extra rail:</strong> {fix.childFix}</p></article>)}</div>
              ) : (
                <div className="gl-residual-parent-wrap"><div className="gl-audit-table-wrap"><table className="gl-audit-table gl-residual-table"><thead><tr><th>Priority</th><th>Residual blocker</th><th>Corrective control</th><th>Owner</th><th>Proof before release</th></tr></thead><tbody>{residualFixes.map((fix) => <tr key={fix.id}><td data-label="Priority"><span className={`gl-priority-dot ${fix.priority.toLowerCase()}`}>{fix.priority}</span></td><th scope="row" data-label="Residual blocker"><strong>{fix.title}</strong><span>{fix.parentIssue}</span></th><td data-label="Corrective control">{fix.parentFix}</td><td data-label="Owner"><span className="gl-owner-stamp">{fix.owner}</span></td><td data-label="Proof before release">{fix.proof}</td></tr>)}</tbody></table></div></div>
              )}

              <div className="gl-proof-dashboard"><div className="gl-proof-dashboard-head"><span className="gl-sequence-kicker">The proof dashboard</span><h4>We do not open a door just because the screen is finished.</h4></div><div className="gl-proof-grid">{proofDashboard.map((item, index) => { const door = ["connect", "chance", "legacy"][index % 3]; const doorLabel = door.charAt(0).toUpperCase() + door.slice(1); return <article key={item.title}><span>{String(index + 1).padStart(2, "0")}</span><div className={`gl-proof-door ${door}`}>{doorLabel} check</div><h5>{item.title}</h5><p>{isChildView ? item.child : item.parent}</p></article>; })}</div></div>

              <div className="gl-corrected-sequence"><div className="gl-sequence-head"><div><span className="gl-sequence-kicker">Current protected release order</span><h3>First the lock. Then the room.</h3></div><p>{isChildView ? "This is our newest map. We only move to the next lantern after the grown-ups can show the safety proof." : "This amended sequence is now the authoritative order. It adds pre-beta recovery, eligibility, lifecycle, operations, cryptographic, model-change, and release-governance controls."}</p></div><ol className="gl-corrected-sequence-list">{correctedSequence.map((item) => <li key={item.step}><span>{item.step}</span><div><strong>{item.title}</strong><p>{isChildView ? item.child : item.parent}</p></div></li>)}</ol></div>
            </div>
          </div>
        </section>

        <section className="gl-section warm" id="trail" aria-labelledby="trail-title">
          <div className="container">
            <div className="gl-section-head">
              <div className="gl-path-stop"><span>03</span><i /> The lantern trail: choose a next stop</div>
              <div className="gl-kicker">The 10 lanterns</div>
              <h2 id="trail-title">Follow the path, one phase at a time.</h2>
              <div className="gl-kid-ribbon"><Compass size={16} /> Pick any lantern. We will explain the simple idea and the careful work behind it.</div>
              <p className="gl-view-status" aria-live="polite"><span>{isChildView ? "Child view" : "Parent view"}</span>{isChildView ? " shows the big idea, why it matters, and the next safe step." : " shows the full delivery scope, dependencies, and evidence needed before release."}</p>
            </div>
            <div className="gl-trail">
              <aside className="gl-trail-rail" aria-label="Choose a roadmap phase">
                <p>Jump to a lantern</p>
                {phases.map((phase) => (
                  <button key={phase.id} onClick={() => choosePhase(phase.id)} className={`gl-phase-jump ${activePhase.id === phase.id ? "active" : ""}`} aria-pressed={activePhase.id === phase.id}>
                    <span>{phase.id}</span> {phase.title}
                  </button>
                ))}
              </aside>
              <div className="gl-phase-content">
                <div className="gl-phase-summary"><p><strong>How the trail works:</strong> a phase is not finished just because a screen exists. It is finished when the promised safety, privacy, testing, and learning evidence is ready too.</p></div>
                <div className="gl-phase-board" aria-label="All GrinLife roadmap phases">
                  {phases.map((phase) => (
                    <button key={phase.id} className={`gl-phase-card ${activePhase.id === phase.id ? "active" : ""}`} onClick={() => choosePhase(phase.id)} aria-label={`Open Phase ${phase.id}: ${phase.title}`}>
                      <div className="gl-phase-card-top"><span className="gl-phase-number">PHASE {phase.id}</span><span className="gl-phase-status">{phase.status}</span></div>
                      <h3>{phase.title}</h3>
                      <p>{phase.short}</p>
                    </button>
                  ))}
                </div>
                <article className={`gl-phase-detail ${isChildView ? "child-view" : "parent-view"}`} id="phase-detail" aria-live="polite">
                  <header className="gl-phase-detail-head">
                    <div><div className="gl-phase-label-row"><span className={`gl-module-token ${activeModule.type}`}>{activeModule.label}</span><span className="gl-kicker">Phase {activePhase.id} · {activePhase.duration} · {activePhase.status}</span></div><h3>{activePhase.title}</h3></div>
                    <div className="gl-door-icon"><ChevronDown size={19} /></div>
                  </header>
                  <div className="gl-trail-compass" aria-label="Trail Compass">
                    <div className="gl-compass-route">
                      <div><span className="gl-compass-kicker">Trail Compass</span><strong>Lantern {activePhaseIndex + 1} of {phases.length}</strong></div>
                      <div className="gl-lantern-dots" aria-label={`Roadmap position: phase ${activePhaseIndex + 1} of ${phases.length}`}>
                        {phases.map((phase, index) => <button key={phase.id} onClick={() => choosePhase(phase.id)} className={`${phase.id === activePhaseId ? "current" : ""} ${exploredPhases.includes(phase.id) ? "explored" : ""}`} aria-label={`Open phase ${index + 1}: ${phase.title}`} aria-current={phase.id === activePhaseId ? "step" : undefined}>{phase.id}</button>)}
                      </div>
                    </div>
                      <div className="gl-compass-actions">
                        <button onClick={() => movePhase(-1)} disabled={activePhaseIndex === 0} aria-label="Open previous phase">← <span>Previous</span></button>
                        <button className={`gl-explored-toggle ${isExplored ? "done" : ""}`} onClick={toggleExplored} aria-pressed={isExplored}>{isExplored ? "Explored" : "Mark explored"}</button>
                        <button onClick={() => movePhase(1)} disabled={activePhaseIndex === phases.length - 1} aria-label="Open next phase"><span>Next</span> →</button>
                      </div>
                      <div className="gl-compass-proof-strip" aria-label={`Proof gates for Phase ${activePhase.id}`}>
                        <div className="gl-compass-proof-copy"><span className="gl-compass-kicker">Proof gates for this lantern</span><strong>{reviewedActiveProofCount} of {activeProofGates.length} reviewed</strong></div>
                        <div className="gl-proof-link-list">{activeProofGates.map((gate) => { const reviewed = reviewedProofLinks.includes(`${activePhaseId}:${gate.id}`); return <button key={gate.id} className={reviewed ? "reviewed" : ""} onClick={() => openProofGate(gate.id)} aria-label={`Open ${gate.title} proof gate${reviewed ? ", reviewed" : ""}`}><span>{reviewed ? "✓" : "→"}</span>{gate.title}</button>; })}</div>
                      </div>
                    </div>
                  {isChildView ? (
                    <div className="gl-child-phase-body">
                      <p className="gl-child-route-note">Your tiny map for this stop: <strong>understand it</strong>, <strong>check it</strong>, then help choose the next safe step.</p>
                      <p className="gl-phase-kid"><strong>In kid words:</strong> {activePhase.kidWords}</p>
                      <div className="gl-child-phase-grid">
                        <section className="gl-child-note purpose"><span>1</span><h4>The big idea</h4><p>{activePhase.short}</p></section>
                        <section className="gl-child-note ready"><span>2</span><h4>Before we move on</h4><p>{activePhase.proof[0]}</p></section>
                        <section className="gl-child-note helper"><span>3</span><h4>Who helps</h4><p>The GrinLife team builds, tests, and checks this step with families and safety helpers before the next lantern lights up.</p></section>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p className="gl-parent-route-note"><span>Parent field note</span> Use this panel to review scope, prerequisites, and release evidence before the team advances the lantern.</p>
                      <p className="gl-phase-kid"><strong>In kid words:</strong> {activePhase.kidWords}</p>
                      <div className="gl-phase-detail-grid">
                        <section className="gl-detail-block" aria-label="What we build in this phase"><h4><Package size={17} /> What the team builds</h4><ul>{activePhase.build.map((item) => <li key={item}>{item}</li>)}</ul></section>
                        <div>
                          <section className="gl-detail-block" aria-label="What must be ready first"><h4><Route size={17} /> What must be ready first</h4><ul>{activePhase.dependsOn.map((item) => <li key={item}>{item}</li>)}</ul></section>
                          <section className="gl-detail-block gate" aria-label="How we know the phase is ready" style={{ marginTop: 18 }}><h4><CheckCircle2 size={17} /> How we know it is ready</h4><ul>{activePhase.proof.map((item) => <li key={item}>{item}</li>)}</ul></section>
                        </div>
                      </div>
                    </>
                  )}
                </article>
              </div>
            </div>
          </div>
        </section>

        <section className="gl-section ink" id="safety" aria-labelledby="safety-title">
          <div className="container gl-module-grid">
            <figure className="gl-photo"><img src={ASSETS.legacy} alt="A warm family memory room with a glowing archive cabinet" /></figure>
            <div className="gl-module-copy">
              <div className="gl-path-stop dark"><span>04</span><i /> Safety follows us everywhere</div>
              <div className="gl-kicker" style={{ color: "#ffd166" }}>The caring rules</div>
              <h2 id="safety-title">We build the safe path before we open the next door.</h2>
              <div className="gl-kid-ribbon dark"><ShieldCheck size={16} /> In kid words: locks, kind helpers, and a clear way out.</div>
              <p>GrinLife must be careful in different ways for different doors. A social match should not open a family memory vault. A person saying yes to one activity should not accidentally say yes to something else. Every important action gets a clear choice and a record.</p>
              <div className="gl-protect-list">
                <div><strong>Connect</strong>People control their profile, broad location, matches, messages, groups, and exits.</div>
                <div><strong>Chance</strong>Every encounter starts with opt-in, has a quick exit, and uses a short, controlled session.</div>
                <div><strong>Legacy</strong>Memories are private by default; sharing needs an explicit grant, and users can revoke it.</div>
                <div><strong>Everywhere</strong>Report, block, moderation, export, delete, backup, restore, and rollout checks are shared promises.</div>
              </div>
              <div className="gl-doorway-row" aria-label="The three GrinLife experience doors"><span className="connect">CONNECT</span><span className="chance">CHANCE</span><span className="legacy">LEGACY</span></div>
            </div>
          </div>
        </section>

        <section className="gl-section mist" id="proof-gates" aria-labelledby="gates-title">
          <div className="container">
            <div className="gl-section-head"><div className="gl-path-stop"><span>05</span><i /> Field notes: prove every promise</div><div className="gl-kicker">Our promise to the team</div><h2 id="gates-title">A pretty screen is not the finish line.</h2><p className="gl-section-intro">Before a phase moves forward, the team needs evidence that it works, keeps people safe, and can be supported in the real world.</p></div>
            <div className="gl-gates gl-field-notes">{proofGates.map((gate) => { const linked = gate.phaseIds.includes(activePhaseId); const reviewed = reviewedProofLinks.includes(`${activePhaseId}:${gate.id}`); return <article id={`proof-gate-${gate.id}`} tabIndex={-1} key={gate.id} className={`gl-gate ${linked ? "linked" : ""} ${highlightedGateId === gate.id ? "spotlight" : ""} ${reviewed ? "reviewed" : ""}`}><div className="gl-gate-icon">{gate.icon}</div><div className="gl-gate-stamp">{linked ? `PHASE ${activePhase.id} LINKED` : "TRAIL GATE"}</div><h3>{gate.title} evidence</h3><p>{isChildView ? gate.child : gate.parent}</p>{linked && <button className="gl-gate-return" onClick={() => { scrollTo("phase-detail"); document.getElementById("phase-detail")?.focus({ preventScroll: true }); }}>Return to Phase {activePhase.id} Compass <ArrowRight size={14} /></button>}</article>; })}</div>
          </div>
        </section>

        <section className="gl-section warm" id="first-90" aria-labelledby="days-title">
          <div className="container">
            <div className="gl-section-head"><div className="gl-path-stop"><span>06</span><i /> First miles: pack, build, invite</div><div className="gl-kicker">The first 90 days</div><h2 id="days-title">Start with a real, safe connection—not a pretend finished product.</h2><div className="gl-kid-ribbon"><Heart size={16} /> In kid words: pack the map, build the base camp, then invite a few people in carefully.</div></div>
            <div className="gl-90-grid gl-field-notes">
              <article className="gl-90-card"><div className="gl-mono">DAYS 1–30</div><h3>Discover & decide</h3><p>Make the old projects understandable and choose what will become the new GrinLife source of truth.</p><ul><li>Audit code, data, deployments, integrations, and content.</li><li>Approve the feature registry, core entities, information architecture, risks, and design direction.</li><li>Document migration and rollback expectations.</li></ul></article>
              <article className="gl-90-card"><div className="gl-mono">DAYS 31–60</div><h3>Build the foundation</h3><p>Make the shared base camp useful before layering on the more exciting product experiences.</p><ul><li>Ship account, privacy center, safety center, notifications, analytics, environments, and real forms.</li><li>Establish encrypted storage baseline, moderation path, backups, restore runbook, smoke tests, and releases.</li><li>Collect M1 evidence.</li></ul></article>
              <article className="gl-90-card"><div className="gl-mono">DAYS 61–90</div><h3>Validate Connect</h3><p>Prove the first small, real user loop with an invited group, then make the next decision from evidence.</p><ul><li>Ship controlled onboarding, matching, messaging, report/block, and safety instrumentation.</li><li>Run defect, feedback, product, and safety reviews.</li><li>Decide whether Chance is ready for a safe beta.</li></ul></article>
            </div>
          </div>
        </section>

        <section className="gl-section mist" id="words" aria-labelledby="words-title">
          <div className="container">
            <div className="gl-section-head"><div className="gl-path-stop"><span>07</span><i /> Trail guide: words we use together</div><div className="gl-kicker">Word helper</div><h2 id="words-title">Big project words, explained simply.</h2><p className="gl-section-intro">A shared vocabulary helps children, families, and the team ask good questions about the roadmap.</p></div>
            <dl className="gl-glossary gl-field-notes">
              <div><dt>Consent</dt><dd>A clear “yes” that someone can change later. It is never hidden or assumed.</dd></div>
              <div><dt>Beta</dt><dd>A small, careful try with real people before something becomes available to everyone.</dd></div>
              <div><dt>Privacy</dt><dd>Rules that let people decide what is theirs, who can see it, and how to take it back.</dd></div>
              <div><dt>Audit trail</dt><dd>A careful notebook showing what important action happened, when, and with whose permission.</dd></div>
              <div><dt>Backup</dt><dd>A protected spare copy that helps bring things back if something breaks.</dd></div>
              <div><dt>Restore drill</dt><dd>A practice run that proves the backup can really help when needed.</dd></div>
              <div><dt>Milestone</dt><dd>A lantern on the trail: a point where the team checks that it is truly ready to continue.</dd></div>
              <div><dt>Feature registry</dt><dd>The master list that protects good ideas so they are not accidentally lost when plans change.</dd></div>
            </dl>
          </div>
        </section>
      </main>

      <footer className="gl-footer">
        <div className="container">
          <div className="gl-footer-grid">
            <div><div className="gl-kicker" style={{ color: "#ffd166" }}>Our final lantern</div><h2>Small steps now make room for bigger memories later.</h2><p>GrinLife is a long-term project. The roadmap protects every feature from the three original ideas while giving the team permission to introduce each one only when the foundation is ready.</p></div>
            <aside className="gl-footer-card"><strong>For the internal team</strong><p>Use this site as the shared explanation layer. The detailed internal delivery blueprint remains the operating reference for engineering, product, trust and safety, AI, commerce, and operations.</p></aside>
          </div>
          <div className="gl-footer-bottom"><span>GrinLife · The Lantern Trail roadmap</span><span>Connect · Chance · Legacy</span></div>
        </div>
      </footer>
    </div>
  );
}

export default Home;
